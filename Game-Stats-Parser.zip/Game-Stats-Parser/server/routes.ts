import type { Express } from "express";
import type { Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  // ✅ IMPORTANT: am scos complet Replit AI integrations (chat/audio/image)
  // ca să nu mai ceară OPENAI_API_KEY la pornire.

  // === User / Faceit Routes ===
  app.post(api.users.create.path, async (req, res) => {
    try {
      const input = api.users.create.input.parse(req.body);

      const existing = await storage.getUserByUsername(input.username);
      if (existing) return res.status(200).json(existing);

      // Fetch real FACEIT data
      let faceitData = {
        faceitId: null as string | null,
        faceitElo: null as number | null,
        faceitAvatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(input.username)}&background=random`,
      };

      const faceitApiKey = process.env.FACEIT_API_KEY;
      if (faceitApiKey) {
        try {
          const response = await fetch(
            `https://open.faceit.com/data/v4/players?nickname=${encodeURIComponent(input.username)}`,
            {
              headers: {
                Authorization: `Bearer ${faceitApiKey}`,
              },
            },
          );

          if (response.ok) {
            const data = await response.json();
            faceitData = {
              faceitId: data.player_id,
              faceitElo:
                data.games?.cs2?.faceit_elo ||
                data.games?.csgo?.faceit_elo ||
                null,
              faceitAvatar: data.avatar || faceitData.faceitAvatar,
            };
          }
        } catch (faceitErr) {
          console.error("FACEIT API error:", faceitErr);
        }
      }

      const user = await storage.createUser({
        ...input,
        ...faceitData,
      });

      return res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join("."),
        });
      }
      console.error(err);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // === Lobby Routes ===
  app.post(api.lobbies.create.path, async (req, res) => {
    const { hostId, map } = req.body;

    const code = Math.random().toString(36).substring(2, 8).toUpperCase();

    const lobby = await storage.createLobby({
      code,
      hostId,
      map,
      side: "CT",
      isActive: true,
    });

    await storage.joinLobby(lobby.id, hostId);

    return res.status(201).json(lobby);
  });

  app.post(api.lobbies.join.path, async (req, res) => {
    const { code, userId } = req.body;
    const lobby = await storage.getLobbyByCode(code);

    if (!lobby) return res.status(404).json({ message: "Lobby not found" });

    await storage.joinLobby(lobby.id, userId);
    return res.status(200).json(lobby);
  });

  app.get(api.lobbies.get.path, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const lobby = await storage.getLobby(id);
    if (!lobby) return res.status(404).json({ message: "Lobby not found" });

    const members = await storage.getLobbyMembers(id);
    return res.json({ ...lobby, members });
  });

  // === WebSockets for Live Lobby Sync ===
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  const lobbyClients = new Map<number, Set<WebSocket>>();

  function broadcastLobbyUpdate(lobbyId: number, data: any) {
    const set = lobbyClients.get(lobbyId);
    if (!set) return;
    // If data has a type (like CHAT_MESSAGE), broadcast it directly
    // Otherwise wrap in lobby_update
    const message = data.type
      ? JSON.stringify(data)
      : JSON.stringify({ type: "lobby_update", data });
    set.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) client.send(message);
    });
  }

  wss.on("connection", (ws) => {
    let currentLobbyId: number | null = null;

    ws.on("message", async (message) => {
      try {
        const data = JSON.parse(message.toString());

        if (data.type === "join_lobby") {
          currentLobbyId = Number(data.lobbyId);
          if (!lobbyClients.has(currentLobbyId)) {
            lobbyClients.set(currentLobbyId, new Set());
          }
          lobbyClients.get(currentLobbyId)!.add(ws);
        }

        if (data.type === "START_MATCH" && currentLobbyId) {
          // Re-broadcast START_MATCH to everyone in lobby
          const set = lobbyClients.get(currentLobbyId);
          if (set) {
            const msg = JSON.stringify({ type: "MATCH_START" });
            set.forEach((client) => {
              if (client.readyState === WebSocket.OPEN) client.send(msg);
            });
          }
        }

        // Optional: events broadcast (quick events / tendencies etc.)
        if (data.type === "EVENT" && currentLobbyId) {
          // Store events if you want: storage.addEvent(...)
          // For now we just rebroadcast to everyone in lobby
          broadcastLobbyUpdate(currentLobbyId, {
            ...(await storage.getLobby(currentLobbyId)),
            members: await storage.getLobbyMembers(currentLobbyId),
          });
        }
      } catch (e) {
        console.error("WS Message error", e);
      }
    });

    ws.on("close", () => {
      if (currentLobbyId && lobbyClients.has(currentLobbyId)) {
        lobbyClients.get(currentLobbyId)!.delete(ws);
      }
    });
  });

  // === Update lobby state (manual + OCR patches) ===
  app.patch(api.lobbies.updateState.path, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const updates = req.body;

    const lobby = await storage.getLobby(id);
    if (!lobby) return res.status(404).json({ message: "Lobby not found" });

    // Handle nested state updates (like tendencies)
    let newState = { ...(lobby.state || {}) };
    const stateKeys = [
      "aggressive",
      "rotate_fast",
      "stack_frequent",
      "repeek",
      "mid_focus",
      "awp_aggressive",
      "force_eco",
      "uses_fakes",
      "antieco_weak",
      "late_rotate",
      "util_heavy",
      "tendencies",
    ];

    let stateUpdated = false;
    for (const key of Object.keys(updates)) {
      if (stateKeys.includes(key)) {
        if (key === "tendencies") {
          newState.tendencies = {
            ...(newState.tendencies || {}),
            ...updates.tendencies,
          };
        } else {
          if (!newState.tendencies) newState.tendencies = {};
          (newState.tendencies as any)[key] = updates[key];
        }
        stateUpdated = true;
      }
    }

    const updatedLobby = await storage.updateLobbyState(id, {
      state: stateUpdated ? newState : lobby.state,
      ...(updates || {}),
    });

    const payload = {
      ...(updatedLobby as any),
      members: await storage.getLobbyMembers(id),
    };

    broadcastLobbyUpdate(id, payload);
    return res.json(payload);
  });

  // === AI Strategy Generation (GEMINI or LOCAL ENGINE) ===
  app.post(api.ai.generate.path, async (req, res) => {
    const {
      lobbyId,
      map,
      side,
      scoreUs,
      scoreThem,
      economyUs,
      economyThem,
      strategyType = "recommended",
    } = req.body;

    try {
      const id = Number(lobbyId);
      const lobby = lobbyId ? await storage.getLobby(id) : null;
      const members = lobbyId ? await storage.getLobbyMembers(id) : [];
      const lobbyState = (lobby as any)?.state || {};

      // Derive TAB economy summary if OCR provided
      const tab = lobbyState?.tab_money;
      if (tab?.team || tab?.enemy) {
        const team = (tab.team || []).map((n: number) => Number(n) || 0);
        const enemy = (tab.enemy || []).map((n: number) => Number(n) || 0);

        const avg = (arr: number[]) => {
          const v = arr.filter((n) => n > 0);
          return Math.round(
            v.reduce((a, b) => a + b, 0) / Math.max(1, v.length),
          );
        };
        const avg_us = avg(team);
        const avg_them = avg(enemy);

        const buyBucket = (a: number) =>
          a < 1800 ? "eco" : a < 3800 ? "force" : "full";

        lobbyState.team_economy = {
          team,
          enemy,
          avg_us,
          avg_them,
          buy_us: buyBucket(avg_us),
          buy_them: buyBucket(avg_them),
        };

        if (lobbyId) await storage.updateLobbyState(id, { state: lobbyState });
      }

      const params = {
        map: map || (lobby as any)?.map || "Mirage",
        side: (side || (lobby as any)?.side || "CT") as "CT" | "T",
        scoreUs: Number(scoreUs ?? (lobby as any)?.scoreUs ?? 0),
        scoreThem: Number(scoreThem ?? (lobby as any)?.scoreThem ?? 0),
        economyUs: economyUs || (lobby as any)?.economyUs || "full",
        economyThem: economyThem || (lobby as any)?.economyThem || "full",
        lobbyState,
        members: (members || []).map((m: any) => ({
          id: m.id,
          username: m.username,
          faceitUsername: m.faceitUsername,
        })),
        strategyType: strategyType as "recommended" | "safe" | "risk",
      };

      let result: any;

      // Use Groq if API key is available, otherwise fallback to local engine
      if (process.env.GROQ_API_KEY) {
        const { generateIGLWithGroq } = await import("./engine/groq-igl");
        const out = await generateIGLWithGroq(params);
        result = {
          primary: out.primary,
          safer: out.safer,
          risk: out.risk,
          selected: out.selected,
          source: "groq",
        };
      } else if (process.env.GEMINI_API_KEY) {
        const { generateIGLWithGemini } = await import("./engine/gemini-igl");
        const out = await generateIGLWithGemini(params);
        result = {
          primary: out.primary,
          safer: out.safer,
          risk: out.risk,
          selected: out.selected,
          source: "gemini",
        };
      } else {
        const { generateIGL } = await import("./engine/igl");
        const out = generateIGL(params);
        result = {
          primary: out.primary,
          safer: out.safer,
          risk: out.risk,
          selected: strategyType,
          source: "local",
        };
      }

      // Broadcast to all lobby members
      if (lobbyId) {
        broadcastLobbyUpdate(id, {
          type: "STRATEGY_UPDATE",
          strategy: result,
        });
      }

      return res.json(result);
    } catch (e) {
      console.error("IGL engine failed:", e);
      return res.status(500).json({ message: "Failed to generate strategy" });
    }
  });

  // === AI Chat endpoint (faster, conversational) ===
  app.post("/api/ai/chat", async (req, res) => {
    const {
      lobbyId,
      map,
      side,
      tendencies,
      message,
      history,
      sender,
      players,
      strategyType,
      economy,
      playerPositions,
    } = req.body;

    try {
      // Broadcast user message to lobby
      if (lobbyId && sender) {
        broadcastLobbyUpdate(Number(lobbyId), {
          type: "CHAT_MESSAGE",
          message: {
            id: `user-${Date.now()}`,
            role: "user",
            content: message,
            timestamp: Date.now(),
            sender,
          },
        });
      }

      if (!process.env.GROQ_API_KEY && !process.env.GEMINI_API_KEY) {
        return res.status(400).json({ message: "No AI API key configured" });
      }

      const chatModule = process.env.GROQ_API_KEY
        ? await import("./engine/groq-chat")
        : await import("./engine/gemini-chat");
      const chatWithIGL =
        (chatModule as any).chatWithIGL ??
        (chatModule as any).default?.chatWithIGL ??
        (chatModule as any).default;

      if (typeof chatWithIGL !== "function") {
        console.error("AI chat module exports:", Object.keys(chatModule));
        return res
          .status(500)
          .json({ message: "AI chat module misconfigured" });
      }

      const result = await chatWithIGL({
        map: map || "Mirage",
        side: side || "CT",
        tendencies: tendencies || {},
        message,
        history: history || [],
        players: players || [],
        strategyType: strategyType || "recommended",
        economy: economy || { lossStreak: 0, roundHistory: [] },
        playerPositions: playerPositions || undefined,
      });

      // Broadcast AI response to lobby
      if (lobbyId) {
        broadcastLobbyUpdate(Number(lobbyId), {
          type: "CHAT_MESSAGE",
          message: {
            id: `assistant-${Date.now()}`,
            role: "assistant",
            content: result.response,
            timestamp: Date.now(),
          },
        });

        // Broadcast if strategy was generated
        if (result.strategy) {
          broadcastLobbyUpdate(Number(lobbyId), {
            type: "STRATEGY_UPDATE",
            strategy: result.strategy,
          });
        }
      }

      return res.json(result);
    } catch (e) {
      console.error("Chat AI failed:", e);
      return res.status(500).json({ message: "AI chat failed" });
    }
  });

  return httpServer;
}
