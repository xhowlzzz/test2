import { db } from "./db";
import { 
    users, lobbies, lobbyMembers, strategies,
    type User, type InsertUser, 
    type Lobby, type InsertLobby,
    type Strategy, type InsertStrategy
} from "@shared/schema";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
    // User / Faceit
    getUser(id: number): Promise<User | undefined>;
    getUserByUsername(username: string): Promise<User | undefined>;
    createUser(user: InsertUser & { faceitId?: string, faceitElo?: number, faceitAvatar?: string }): Promise<User>;

    // Lobbies
    createLobby(lobby: InsertLobby): Promise<Lobby>;
    getLobby(id: number): Promise<Lobby | undefined>;
    getLobbyByCode(code: string): Promise<Lobby | undefined>;
    joinLobby(lobbyId: number, userId: number): Promise<void>;
    getLobbyMembers(lobbyId: number): Promise<(User & { isReady: boolean, role: string | null })[]>;
    updateLobbyState(id: number, state: Partial<Lobby>): Promise<Lobby>;

    // Strategies
    getStrategies(): Promise<Strategy[]>;
    createStrategy(strategy: InsertStrategy): Promise<Strategy>;
}

export class DatabaseStorage implements IStorage {
    async getUser(id: number): Promise<User | undefined> {
        const [user] = await db.select().from(users).where(eq(users.id, id));
        return user;
    }

    async getUserByUsername(username: string): Promise<User | undefined> {
        const [user] = await db.select().from(users).where(eq(users.username, username));
        return user;
    }

    async createUser(insertUser: InsertUser & { faceitId?: string, faceitElo?: number, faceitAvatar?: string }): Promise<User> {
        const [user] = await db.insert(users).values(insertUser).returning();
        return user;
    }

    async createLobby(insertLobby: InsertLobby): Promise<Lobby> {
        const [lobby] = await db.insert(lobbies).values(insertLobby).returning();
        return lobby;
    }

    async getLobby(id: number): Promise<Lobby | undefined> {
        const [lobby] = await db.select().from(lobbies).where(eq(lobbies.id, id));
        return lobby;
    }

    async getLobbyByCode(code: string): Promise<Lobby | undefined> {
        const [lobby] = await db.select().from(lobbies).where(eq(lobbies.code, code));
        return lobby;
    }

    async joinLobby(lobbyId: number, userId: number): Promise<void> {
        // Check if already member
        const [existing] = await db.select().from(lobbyMembers)
            .where(sql`${lobbyMembers.lobbyId} = ${lobbyId} AND ${lobbyMembers.userId} = ${userId}`);
        
        if (!existing) {
            await db.insert(lobbyMembers).values({
                lobbyId,
                userId
            });
        }
    }

    async getLobbyMembers(lobbyId: number): Promise<(User & { isReady: boolean, role: string | null })[]> {
        const results = await db.select({
            id: users.id,
            username: users.username,
            faceitId: users.faceitId,
            faceitElo: users.faceitElo,
            faceitAvatar: users.faceitAvatar,
            preferredRole: users.preferredRole,
            createdAt: users.createdAt,
            isReady: lobbyMembers.isReady,
            role: lobbyMembers.role
        })
        .from(lobbyMembers)
        .innerJoin(users, eq(lobbyMembers.userId, users.id))
        .where(eq(lobbyMembers.lobbyId, lobbyId));
        
        return results.map(r => ({
            ...r,
            isReady: r.isReady ?? false
        }));
    }

    async updateLobbyState(id: number, updates: Partial<Lobby>): Promise<Lobby> {
        const [lobby] = await db.update(lobbies)
            .set(updates)
            .where(eq(lobbies.id, id))
            .returning();
        return lobby;
    }

    async getStrategies(): Promise<Strategy[]> {
        return await db.select().from(strategies);
    }

    async createStrategy(insertStrategy: InsertStrategy): Promise<Strategy> {
        const [strategy] = await db.insert(strategies).values(insertStrategy).returning();
        return strategy;
    }
}

export const storage = new DatabaseStorage();
