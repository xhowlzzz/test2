import { Router } from "express";
import { storage } from "../storage";

const router = Router();

const FACEIT_CLIENT_ID = process.env.FACEIT_CLIENT_ID;
const FACEIT_CLIENT_SECRET = process.env.FACEIT_CLIENT_SECRET;
const BASE_URL = process.env.REPL_SLUG 
  ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER?.toLowerCase()}.repl.co`
  : "http://localhost:5000";
const REDIRECT_URI = `${BASE_URL}/api/auth/faceit/callback`;

const FACEIT_AUTH_URL = "https://accounts.faceit.com";
const FACEIT_API_URL = "https://api.faceit.com";

router.get("/faceit", (req, res) => {
  if (!FACEIT_CLIENT_ID) {
    return res.status(500).json({ error: "FACEIT_CLIENT_ID not configured" });
  }

  const state = Math.random().toString(36).substring(7);
  
  const authUrl = new URL(`${FACEIT_AUTH_URL}/oauth/authorize`);
  authUrl.searchParams.set("client_id", FACEIT_CLIENT_ID);
  authUrl.searchParams.set("redirect_uri", REDIRECT_URI);
  authUrl.searchParams.set("response_type", "code");
  authUrl.searchParams.set("scope", "openid email profile");
  authUrl.searchParams.set("state", state);

  res.redirect(authUrl.toString());
});

router.get("/faceit/callback", async (req, res) => {
  const { code, error } = req.query;

  if (error) {
    return res.redirect(`/?error=${encodeURIComponent(String(error))}`);
  }

  if (!code) {
    return res.redirect("/?error=no_code");
  }

  if (!FACEIT_CLIENT_ID || !FACEIT_CLIENT_SECRET) {
    return res.redirect("/?error=not_configured");
  }

  try {
    const tokenResponse = await fetch(`${FACEIT_AUTH_URL}/oauth/token`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": `Basic ${Buffer.from(`${FACEIT_CLIENT_ID}:${FACEIT_CLIENT_SECRET}`).toString("base64")}`,
      },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        code: String(code),
        redirect_uri: REDIRECT_URI,
      }),
    });

    if (!tokenResponse.ok) {
      const errorText = await tokenResponse.text();
      console.error("Token exchange error:", errorText);
      return res.redirect("/?error=token_exchange_failed");
    }

    const tokens = await tokenResponse.json();
    const accessToken = tokens.access_token;
    const idToken = tokens.id_token;

    let userData: any = {};
    
    if (idToken) {
      try {
        const payload = idToken.split(".")[1];
        const decoded = JSON.parse(Buffer.from(payload, "base64").toString());
        userData = {
          faceitId: decoded.guid || decoded.sub,
          nickname: decoded.nickname,
          email: decoded.email,
          avatar: decoded.picture,
        };
      } catch (e) {
        console.error("ID token decode error:", e);
      }
    }

    if (!userData.nickname && accessToken) {
      try {
        const userInfoResponse = await fetch(`${FACEIT_API_URL}/auth/v1/userinfo`, {
          headers: {
            "Authorization": `Bearer ${accessToken}`,
          },
        });
        if (userInfoResponse.ok) {
          const userInfo = await userInfoResponse.json();
          userData = {
            faceitId: userInfo.guid || userInfo.sub,
            nickname: userInfo.nickname,
            email: userInfo.email,
            avatar: userInfo.picture,
          };
        }
      } catch (e) {
        console.error("UserInfo fetch error:", e);
      }
    }

    if (!userData.nickname) {
      return res.redirect("/?error=no_user_data");
    }

    let elo: number | undefined;
    if (userData.faceitId) {
      try {
        const statsResponse = await fetch(
          `https://open.faceit.com/data/v4/players/${userData.faceitId}`,
          {
            headers: {
              "Authorization": `Bearer ${process.env.FACEIT_API_KEY || ""}`,
            },
          }
        );
        if (statsResponse.ok) {
          const stats = await statsResponse.json();
          elo = stats.games?.cs2?.faceit_elo || stats.games?.csgo?.faceit_elo;
        }
      } catch (e) {
        console.error("ELO fetch error:", e);
      }
    }

    const user = await storage.createUser({
      username: userData.nickname,
      faceitId: userData.faceitId,
      faceitElo: elo,
      faceitAvatar: userData.avatar,
    });

    res.redirect(`/lobbies?userId=${user.id}&username=${encodeURIComponent(user.username)}&faceit=true`);
  } catch (error) {
    console.error("FACEIT OAuth error:", error);
    res.redirect("/?error=auth_failed");
  }
});

router.get("/faceit/status", (req, res) => {
  res.json({
    configured: !!(FACEIT_CLIENT_ID && FACEIT_CLIENT_SECRET),
    redirectUri: REDIRECT_URI,
  });
});

export default router;
