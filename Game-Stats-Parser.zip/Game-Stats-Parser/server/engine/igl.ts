export type LobbyState = any;

type Call = {
  title: string;
  type: "primary"|"safe"|"risk";
  map: string;
  side: "T"|"CT";
  content: {
    voice: string;
    quick: { buy: string; plan: string; fallback: string; drops?: string[] };
    layering: string[];
    roles: Record<string,string>;
    utility: string[];
    triggers: string[];
    win_conditions: string[];
    failure_branches: string[];
    notes?: string[];
  };
};

export function generateIGL({ map, side, scoreUs, scoreThem, economyUs, economyThem, lobbyState, members }:{
  map: string;
  side: "T"|"CT";
  scoreUs: number;
  scoreThem: number;
  economyUs: string;
  economyThem: string;
  lobbyState: LobbyState;
  members: Array<{ id:number; username:string; faceitUsername?:string }>;
}) {
  const diff = scoreUs - scoreThem;

  const tendencies = lobbyState?.tendencies || {};
  const teamEcon = lobbyState?.team_economy || null; // { team:[], enemy:[], avg_us, avg_them, buy_us, buy_them }
  const buyUs = teamEcon?.buy_us || economyUs || "full";
  const buyThem = teamEcon?.buy_them || economyThem || "full";

  const drops = computeDrops(teamEcon?.team || []);

  const base = buildPlan({ map, side, buyUs, buyThem, diff, tendencies, members });

  const primary = makeVariant(base, "primary", drops, diff);
  const safe = makeVariant(base, "safe", drops, diff);
  const risk = makeVariant(base, "risk", drops, diff);

  // Apply variations after cloning
  safe.content.title = "Safe Strategy: " + base.title;
  safe.content.voice = "Safe/Passive: " + base.voice.replace("default", "passive");
  safe.content.quick.plan = "Play for picks, don't overextend. Use utility to delay and maintain space.";
  safe.content.quick.buy = base.quick.buy + " (Add extra kit/util)";
  
  risk.content.title = "High Risk Strategy: " + base.title;
  risk.content.voice = "Aggressive/Fast: " + base.voice.replace("default", "aggressive");
  risk.content.quick.plan = "High pace, contact plays, force the issue early with coordinated aggression.";
  risk.content.quick.buy = base.quick.buy + " (Aggressive focus)";

  // Score them simply
  primary.content.notes = buildNotes({ buyUs, buyThem, tendencies, teamEcon });
  safe.content.notes = buildNotes({ buyUs, buyThem, tendencies, teamEcon });
  risk.content.notes = buildNotes({ buyUs, buyThem, tendencies, teamEcon });

  return { primary, safer: safe, risk };
}

function computeDrops(teamMoney: number[]) {
  const rich = teamMoney.map((m,i)=>({m,i})).filter(x=>x.m>=5200).sort((a,b)=>b.m-a.m);
  const poor = teamMoney.map((m,i)=>({m,i})).filter(x=>x.m>0 && x.m<=1800).sort((a,b)=>a.m-b.m);
  const n = Math.min(rich.length, poor.length);
  const out: string[] = [];
  for (let k=0;k<n;k++) out.push(`P${rich[k].i+1} → P${poor[k].i+1}`);
  return out;
}

function makeVariant(base: any, kind:"primary"|"safe"|"risk", drops:string[], diff:number): Call {
  const mod = structuredClone(base);
  if (kind === "safe") {
    mod.voice = mod.voice.replace("explode","default");
    mod.quick.fallback = "If entry lost: reset + save guns, play late / contact.";
    mod.triggers = [...mod.triggers, "If we get first pick: slow down and trade, don’t over-chase."];
  }
  if (kind === "risk") {
    mod.voice = mod.voice.replace("default","fast");
    mod.quick.plan = mod.quick.plan.replace("default","contact");
    mod.layering = mod.layering.map((x:string)=>x.replace("safe", "fast"));
    mod.triggers = [...mod.triggers, "If they stack: commit anyway with pace (risk)."];
  }
  // scoreline
  if (diff >= 3 && kind === "safe") mod.quick.plan = "Play percentage: trade, avoid solo duels.";
  if (diff <= -3 && kind === "risk") mod.quick.plan = "Comeback: faster hit + force rotates.";

  if (drops.length) mod.quick.drops = drops;

  return {
    title: kind === "primary" ? "Primary Call" : kind === "safe" ? "Safer Alternative" : "High‑Variance",
    type: kind === "primary" ? "primary" : kind === "safe" ? "safe" : "risk",
    map: base.map,
    side: base.side,
    content: mod
  };
}

function buildPlan({ map, side, buyUs, buyThem, diff, tendencies, members }:{
  map:string; side:"T"|"CT"; buyUs:string; buyThem:string; diff:number; tendencies:any; members:any[];
}) {
  const roles = assignRoles(members);

  const antiAggro = tendencies.aggressive ? "punish early aggro with flash + trade" : "default info";
  const antiRotate = tendencies.rotate_fast ? "show A util then late pivot" : "late probe then exec";
  const antiStack = tendencies.stack_frequent ? "probe 2-1-2 then late pivot" : "standard";

  const buyLine = buyUs === "eco" ? "Eco: stack + pistols, play close trades" :
                  buyUs === "force" ? "Force: rifles if possible + 2 flashes" :
                  "Full: rifles + util, one late smoke for endgame";

  const baseT = {
    voice: `Default ${map} — ${antiAggro}, ${antiRotate}.`,
    quick: {
      buy: buyLine,
      plan: `20s: ${antiStack} → take mid control 20–35s → exec late.`,
      fallback: `If mid lost: give up, regroup, hit site with util at 0:45.`
    },
    layering: [
      "Strat 1 (0:20–1:25): default map control, no solo peeks, pair-trade.",
      "Strat 2 (react): if they fight mid, use 2 flashes then fall back; if quiet, take space.",
      "Strat 3 (0:55–0:25): late exec / fake depending on rotations.",
      "Strat 4 (endgame): plant protocol + post-plant crossfire, don’t chase."
    ],
    roles: {
      Entry: roles.entry,
      "Second Entry": roles.second,
      Support: roles.support,
      Lurk: roles.lurk,
      Anchor: roles.anchor
    },
    utility: [
      `${roles.support}: 2 flashes for entry timing`,
      `${roles.entry}: smoke main choke on exec`,
      `${roles.second}: trade spacing 1–2m behind entry`,
      `${roles.lurk}: hold rotate cut (don’t die early)`
    ],
    triggers: [
      "If first pick for us: slow down, trade, end with numbers.",
      "If time < 0:40 and no space: commit to nearest site with 2 util.",
      "If they rotate fast: fake util then late pivot."
    ],
    win_conditions: [
      "Trade kills (no solo fights)",
      "Keep one late smoke for plant / retake denial",
      "Use time: don’t exec into 5 stacks without info"
    ],
    failure_branches: [
      "If entry dies: pause, flash re-peek only if 2nd can trade; otherwise reset.",
      "If mid lost early: stop feeding, hit site with 4, keep lurk for rotate.",
      "If down to 0:25: go contact and plant ASAP."
    ]
  };

  const baseCT = {
    voice: `CT default ${map} — trade, no hero peeks.`,
    quick: {
      buy: buyLine,
      plan: "20s: 2‑1‑2 default, contest key lane with util, fall back on damage.",
      fallback: "If pick lost: don’t re-peek, retake protocol 3‑2."
    },
    layering: [
      "Strat 1 (0:20–1:25): early info with safe util, deny lane.",
      "Strat 2 (react): if pressure A/B, call rotate early (no solo).",
      "Strat 3 (0:55–0:25): hold crossfires, keep one smoke for retake.",
      "Strat 4 (endgame): 3‑2 retake, trade entries, clear common spots."
    ],
    roles: {
      Anchor: roles.anchor,
      Rotator: roles.second,
      Support: roles.support,
      "Mid Info": roles.entry,
      Flex: roles.lurk
    },
    utility: [
      `${roles.support}: early smoke/molo to delay`,
      `${roles.anchor}: survive, call numbers, play crossfire`,
      `${roles.second}: rotate on info, don’t over-rotate on fakes`
    ],
    triggers: [
      "If they take mid fast: give up and play retake angles.",
      "If they show heavy util: assume exec, rotate 1 early.",
      "If 0:35 and no contact: stack closer but keep 1 anchor."
    ],
    win_conditions: [
      "Stay alive and trade",
      "Delay with util, don’t dry peek AWP",
      "Retake together, not staggered"
    ],
    failure_branches: [
      "If first pick lost: turtle, play 2-man holds, save util.",
      "If site lost: call save vs 2v4, keep rifles.",
      "If time low: re-take with flashes, don’t slow-walk."
    ]
  };

  const base = side === "T" ? baseT : baseCT;
  return { ...base, map, side };
}

function assignRoles(members: any[]) {
  const names = members.map(m => m.username);
  const pick = (i:number) => names[i] || `P${i+1}`;
  return {
    entry: pick(0),
    second: pick(1),
    support: pick(2),
    lurk: pick(3),
    anchor: pick(4)
  };
}

function buildNotes({ buyUs, buyThem, tendencies, teamEcon }:{ buyUs:string; buyThem:string; tendencies:any; teamEcon:any }) {
  const notes:string[] = [];
  if (teamEcon?.avg_us) notes.push(`TAB avg us: $${teamEcon.avg_us} (${teamEcon.buy_us})`);
  if (teamEcon?.avg_them) notes.push(`TAB avg them: $${teamEcon.avg_them} (${teamEcon.buy_them})`);
  if (tendencies.stack_frequent) notes.push("They stack: probe + late pivot recommended.");
  if (tendencies.rotate_fast) notes.push("They rotate fast: fake util then late hit.");
  if (tendencies.aggressive) notes.push("They peek: punish with flash + trade.");
  if (buyUs === "eco") notes.push("Hard eco: prioritize close trades + stacked site.");
  if (buyThem === "eco") notes.push("Anti-eco: clear corners, avoid solo chases.");
  return notes;
}
