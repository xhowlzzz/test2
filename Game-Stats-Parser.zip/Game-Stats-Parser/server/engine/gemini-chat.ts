import Groq from "groq-sdk";
import { getCallouts } from "./cs2-callouts";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY || "" });

type ChatMessage = { role: "user" | "assistant"; content: string };
type Player = { username: string; role?: string };
type Economy = {
  lossStreak: number;
  roundHistory: Array<{ won: boolean; planted?: boolean }>;
};

type StrategyType = "recommended" | "safe" | "risk";
type Side = "CT" | "T";

type PlanAction = {
  player: string;
  verb:
    | "merge"
    | "ține"
    | "lurk"
    | "entry"
    | "trade"
    | "rotate"
    | "retake"
    | "clear"
    | "delay"
    | "default";
  position: string; // MUST be canonical callout
  note?: string;
};

type PlanPhase = {
  phase: 1 | 2 | 3 | 4;
  actions: PlanAction[];
};

type UtilityItem = {
  player: string;
  type: "smoke" | "flash" | "molly" | "nade";
  position: string; // MUST be canonical callout
  purpose?: string;
  timing?: string;
};

type StrategyPlan = {
  decision: "FULL BUY" | "FORCE" | "ECO" | "HALF-BUY";
  voice: string;
  quick: { buy: string; plan: string; fallback: string };
  layering: PlanPhase[];
  utility: UtilityItem[];
};

type IGLPayload = {
  selected?: StrategyType;
  strategies: Record<StrategyType, StrategyPlan>;
  notes?: string[];
};

export async function chatWithIGL({
  map,
  side,
  tendencies,
  message,
  history,
  players,
  strategyType,
  economy,
}: {
  map: string;
  side: Side;
  tendencies: Record<string, boolean>;
  message: string;
  history: ChatMessage[];
  players?: Player[];
  strategyType?: StrategyType;
  economy?: Economy;
}): Promise<{ response: string; strategy?: any }> {
  const tendencyLabels: Record<string, string> = {
    aggressive: "Agresivi",
    rotate_fast: "Rotează rapid",
    stack_frequent: "Stack frecvent",
    repeek: "Re-peek",
    mid_focus: "Mid focus",
    awp_aggressive: "AWP agresiv",
    force_eco: "Force des",
    uses_fakes: "Folosesc fakes",
    antieco_weak: "Slabi anti-eco",
    late_rotate: "Late rotate",
    util_heavy: "Util heavy",
  };

  const activeTendencies =
    Object.entries(tendencies)
      .filter(([, v]) => v)
      .map(([k]) => tendencyLabels[k] || k)
      .join(", ") || "necunoscute";

  const playerNames = players?.map((p) => p.username) || [
    "P1",
    "P2",
    "P3",
    "P4",
    "P5",
  ];
  const p1 = playerNames[0] || "P1";
  const p2 = playerNames[1] || "P2";
  const p3 = playerNames[2] || "P3";
  const p4 = playerNames[3] || "P4";
  const p5 = playerNames[4] || "P5";

  // Economy context (lightweight, stable)
  const lossStreak = economy?.lossStreak ?? 0;
  const lossBonusTable = [1400, 1900, 2400, 2900, 3400, 3400];
  const lossBonus = lossBonusTable[Math.min(lossStreak, 5)];
  const roundCount = economy?.roundHistory?.length ?? 0;
  const lastRound =
    roundCount > 0 ? economy!.roundHistory[roundCount - 1] : undefined;

  const economyContext =
    roundCount === 0
      ? "Pistol round (start $800/jucător)."
      : `Runde jucate: ${roundCount}. Ultima rundă: ${lastRound?.won ? "WIN" : "LOSS"}${
          lastRound?.planted ? " + PLANT" : ""
        }. Loss streak: ${lossStreak}. Dacă pierzi iar: loss bonus $${lossBonus}.`;

  // --- Callouts: build strict allowed list + keep original text for context
  const mapCalloutsText = String(getCallouts(map) ?? "");
  const allowedCallouts = extractCalloutNames(mapCalloutsText);

  // If getCallouts(map) returns something un-parseable, fall back to a minimal list to avoid empty enum.
  const fallbackAllowed = ["T Spawn", "Mid", "A Site", "B Site", "CT Spawn"];
  const allowed =
    allowedCallouts.length >= 10 ? allowedCallouts : fallbackAllowed;

  // --- "Memory": extract last few assistant plans to reduce repetition
  const sessionMemory = buildSessionMemory(history);

  const sideInstructions =
    side === "CT"
      ? `
EȘTI CT (apărare). Focus: HOLD, INFO, ROTATE, RETAKE, CROSSFIRES.
Nu vorbi ca T (fără "plantăm", fără "execute pe site").`
      : `
EȘTI T (atac). Focus: MAP CONTROL, EXECUTE, ENTRY+TRADE, PLANT, POST-PLANT.
Nu vorbi ca CT (fără "ancoră site", fără "retake").`;

  const systemPrompt = `
Ești un IGL profesionist pentru CS2 și vorbești DOAR în română.
Răspunzi DOAR cu JSON valid (fără markdown, fără text în afara JSON).

HARTA: ${map.toUpperCase()} | SIDE: ${side}
JUCĂTORI: ${p1}, ${p2}, ${p3}, ${p4}, ${p5}
ECONOMIE: ${economyContext}
TENDINȚE INAMICE: ${activeTendencies}

${sideInstructions}

MEMORIE SESIUNE (NU repeta aceeași idee identic):
${sessionMemory}

CALLOUT VOCABULAR (POZIȚII PERMISE - trebuie să alegi EXACT unul din listă pentru fiecare "position"):
${JSON.stringify(allowed, null, 2)}

REGULI ECONOMIE (orientativ, decide tu):
- Sub $2,000/jucător: ECO (pistoale / save)
- $2,000–$3,500: HALF-BUY sau FORCE (în funcție de rundă și util)
- $4,500+: FULL BUY

TASK:
Generează 3 strategii DISTINCTE pentru runda curentă:
1) recommended (echilibrat)
2) safe (low risk, info-first)
3) risk (high tempo, agresiv)

Fiecare strategie trebuie să includă:
- decision: FULL BUY / FORCE / ECO / HALF-BUY
- voice: un call scurt de IGL (1-2 propoziții)
- quick: buy/plan/fallback
- layering: exact 4 faze (phase 1..4), iar în fiecare fază să apară toți cei 5 jucători cel puțin o dată în total
- utility: minim 4 utilități totale (dacă e eco, pune "flash" simple sau "nade" cheap)

IMPORTANT:
- Câmpul "position" trebuie să fie EXACT un string din lista CALLOUT VOCABULAR.
- Nu inventa poziții, nu folosi alias-uri în "position" (dacă vrei alias, pune-l în note).
- Variază ideile (nu repeta aceeași execuție identic în toate 3 strategiile).

FORMAT OUTPUT (obligatoriu):
{
  "selected": "recommended" | "safe" | "risk",
  "strategies": {
    "recommended": { ...StrategyPlan },
    "safe": { ...StrategyPlan },
    "risk": { ...StrategyPlan }
  },
  "notes": ["optional"]
}
`.trim();

  const chatHistory = history.map((m) => ({
    role: m.role === "user" ? ("user" as const) : ("assistant" as const),
    content: m.content,
  }));

  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: systemPrompt },
        ...chatHistory,
        { role: "user", content: message },
      ],
      // JSON mode (best effort). Some SDK typings may not include this, so we cast.
      ...({ response_format: { type: "json_object" } } as any),
      max_tokens: 1600,
      temperature: 0.35,
      // seed helps reduce randomness if supported
      ...({ seed: 7 } as any),
    });

    const rawText = response.choices[0]?.message?.content || "";

    // Parse robustly (JSON mode should work, but fallback just in case)
    const parsed =
      safeJsonParse(rawText) ??
      safeJsonParse(extractJsonObject(rawText)) ??
      null;

    // If model didn't follow schema, fallback to previous behavior
    if (!parsed || typeof parsed !== "object") {
      const fallbackText = rawText.trim();
      return {
        response:
          fallbackText || "Nu am putut genera un plan (format invalid).",
        strategy: buildFallbackStrategy(
          rawText,
          map,
          side,
          strategyType || "recommended",
        ),
      };
    }

    // Normalize to our payload shape
    const payload = coercePayload(parsed as any, strategyType);

    // Sanitize callouts (fix common alias/typo cases → canonical allowed list)
    const notes: string[] = [];
    sanitizePayloadCallouts(payload, allowed, notes);

    // Choose selected strategy
    const selectedKey: StrategyType =
      strategyType || payload.selected || "recommended";

    const selectedPlan =
      payload.strategies[selectedKey] || payload.strategies.recommended;

    // Render a nice text response that includes all 3 strategies
    const responseText = renderThreeStrategies(payload.strategies, selectedKey);

    // Build your existing "strategy" object (now with 3 options)
    const strategy = buildStrategyObject(
      payload.strategies,
      selectedKey,
      map,
      side,
    );

    if (notes.length) {
      payload.notes = [...(payload.notes || []), ...notes];
      // Append notes at end (optional)
      // (We keep responseText clean; UI can show payload.notes if you want)
    }

    return { response: responseText, strategy };
  } catch (error) {
    console.error("Groq chat error:", error);
    throw error;
  }
}

/* -----------------------------
   Helpers: Memory (minte)
------------------------------ */

function buildSessionMemory(history: ChatMessage[], max = 4): string {
  // Extract last few assistant JSON plans (decision + a short summary)
  const items: Array<{ decision?: string; voice?: string; plan?: string }> = [];
  for (let i = history.length - 1; i >= 0 && items.length < max; i--) {
    const m = history[i];
    if (m.role !== "assistant") continue;
    const obj =
      safeJsonParse(m.content) ?? safeJsonParse(extractJsonObject(m.content));
    if (!obj) continue;

    // Support both old and new structures
    const decision = (obj as any)?.decision;
    const voice = (obj as any)?.voice;
    const plan = (obj as any)?.quick?.plan;

    // New structure
    const strategies = (obj as any)?.strategies;
    const rec = strategies?.recommended;
    const recDecision = rec?.decision;
    const recVoice = rec?.voice;
    const recPlan = rec?.quick?.plan;

    items.push({
      decision: decision || recDecision,
      voice: voice || recVoice,
      plan: plan || recPlan,
    });
  }

  if (!items.length) return "- (nu există call-uri anterioare)";

  return items
    .map((it, idx) => {
      const d = it.decision ? `[${it.decision}]` : "";
      const v = it.voice ? it.voice : "(fără voice)";
      const p = it.plan ? it.plan : "(fără plan)";
      // Keep short
      return `- Ultimul#${idx + 1}: ${d} ${truncate(v, 90)} | plan: ${truncate(p, 110)}`;
    })
    .join("\n");
}

function truncate(s: string, n: number): string {
  const t = String(s || "");
  return t.length <= n ? t : t.slice(0, n - 1) + "…";
}

/* -----------------------------
   Helpers: Callouts extraction
------------------------------ */

function extractCalloutNames(calloutsText: string): string[] {
  // Tries to extract canonical callout strings from getCallouts(map) output.
  // Works with lists like:
  // "- Palace", "A Site: Palace, Ramp, Default", "Palace – description", etc.
  const lines = String(calloutsText || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const names = new Set<string>();

  for (const line of lines) {
    // remove code fences/backticks if any
    const clean = line.replace(/```/g, "").trim();

    // skip obvious headers
    if (/^[-=]{3,}$/.test(clean)) continue;
    if (/^HARTA|^CALLOUT|^FORMAT|^REGULI/i.test(clean)) continue;

    // drop leading bullets/numbers
    let l = clean.replace(/^\s*[-*•]+\s*/, "");
    l = l.replace(/^\s*\d+[\.\)]\s*/, "");

    // If it contains ":", split after colon (category prefix)
    if (l.includes(":")) {
      const parts = l.split(":");
      // Keep right side if it looks like a list
      if (parts.length >= 2 && parts.slice(1).join(":").length > 2) {
        l = parts.slice(1).join(":").trim();
      }
    }

    // Remove description separator " - " or " – "
    l = l.split(" – ")[0].split(" - ")[0].trim();

    // Split by commas if it's a list
    const candidates = l.includes(",") ? l.split(",") : [l];

    for (const c of candidates) {
      const name = c.trim();
      if (!name) continue;
      // filter very long fragments
      if (name.length > 40) continue;
      // must contain at least a letter
      if (!/[a-zA-ZăîâșțĂÎÂȘȚ]/.test(name)) continue;
      // avoid generic words
      if (/^(site|mid|spawn|a|b)$/i.test(name)) continue;

      names.add(name);
    }
  }

  // Keep stable order, but unique
  const arr = Array.from(names);
  // small heuristic: sort by length then alpha to reduce instability
  arr.sort((a, b) => a.length - b.length || a.localeCompare(b));
  return arr;
}

function normalizeCallout(s: string): string {
  return String(s || "")
    .toLowerCase()
    .replace(/[’'`"]/g, "")
    .replace(/[\(\)\[\]\{\}]/g, "")
    .replace(/[^a-z0-9ăîâșț\/\s-]/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

// Common alias resolver across maps (best effort)
// We map alias → preferred canonical name IF it exists in allowed list.
function resolveCalloutToAllowed(
  input: string,
  allowed: string[],
): string | null {
  if (!input) return null;

  // exact match
  if (allowed.includes(input)) return input;

  const normAllowed = new Map<string, string>();
  for (const a of allowed) normAllowed.set(normalizeCallout(a), a);

  const norm = normalizeCallout(input);
  if (normAllowed.has(norm)) return normAllowed.get(norm)!;

  // alias patterns (try to pick a canonical that exists)
  const aliasCandidates: Array<{ re: RegExp; wants: string[] }> = [
    { re: /\bconn\b|\bconnector\b/i, wants: ["Connector", "Conn"] },
    {
      re: /\bapps?\b|\bapts?\b|\bapartments\b/i,
      wants: ["Apartments", "Aps", "Apps", "B Apartments"],
    },
    {
      re: /\bcat\b|\bcatwalk\b|\bshort\b/i,
      wants: ["Short", "Catwalk", "Cat"],
    },
    { re: /\bticket\b|\bbooth\b/i, wants: ["Ticket", "Booth"] },
    { re: /\bwindow\b/i, wants: ["Window", "Mid Window"] },
    { re: /\bdefault\b/i, wants: ["Default"] },
    { re: /\bct\b\s*spawn\b|\bctspawn\b/i, wants: ["CT Spawn"] },
    { re: /\bt\s*spawn\b|\btspawn\b/i, wants: ["T Spawn"] },
    { re: /\ba\s*main\b/i, wants: ["A Main"] },
    { re: /\bb\s*main\b/i, wants: ["B Main"] },
    { re: /\blong\b/i, wants: ["Long", "A Long"] },
    { re: /\bbanana\b/i, wants: ["Banana"] },
  ];

  for (const rule of aliasCandidates) {
    if (!rule.re.test(input)) continue;
    for (const want of rule.wants) {
      // prefer exact contains match from allowed
      const found = allowed.find(
        (a) => normalizeCallout(a) === normalizeCallout(want),
      );
      if (found) return found;
      const found2 = allowed.find((a) =>
        normalizeCallout(a).includes(normalizeCallout(want)),
      );
      if (found2) return found2;
    }
  }

  // last resort: try substring match
  for (const [na, canonical] of Array.from(normAllowed.entries())) {
    if (na.includes(norm) || norm.includes(na)) return canonical;
  }

  return null;
}

/* -----------------------------
   Helpers: JSON parse / coerce
------------------------------ */

function safeJsonParse(text: string): any | null {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function extractJsonObject(text: string): string {
  const raw = String(text || "");
  const match = raw.match(/\{[\s\S]*\}/);
  return match ? match[0] : "{}";
}

function coercePayload(obj: any, preferred?: StrategyType): IGLPayload {
  const emptyPlan = (): StrategyPlan => ({
    decision: "ECO",
    voice: "Eco și jucăm pentru pick/stack.",
    quick: { buy: "", plan: "", fallback: "" },
    layering: [
      { phase: 1, actions: [] },
      { phase: 2, actions: [] },
      { phase: 3, actions: [] },
      { phase: 4, actions: [] },
    ],
    utility: [],
  });

  // If model returned the old schema (single plan), wrap it.
  if (!obj?.strategies) {
    const plan: StrategyPlan = {
      decision: obj?.decision || "ECO",
      voice: obj?.voice || "",
      quick: {
        buy: obj?.quick?.buy || "",
        plan: obj?.quick?.plan || "",
        fallback: obj?.quick?.fallback || "",
      },
      layering: Array.isArray(obj?.layering) ? obj.layering : [],
      utility: Array.isArray(obj?.utility) ? obj.utility : [],
    };

    return {
      selected: preferred || "recommended",
      strategies: {
        recommended: plan,
        safe: emptyPlan(),
        risk: emptyPlan(),
      },
      notes: ["Model a returnat format vechi; am încercat să adaptez."],
    };
  }

  const strategies = obj.strategies || {};
  return {
    selected: preferred || obj.selected || "recommended",
    strategies: {
      recommended: strategies.recommended || emptyPlan(),
      safe: strategies.safe || emptyPlan(),
      risk: strategies.risk || emptyPlan(),
    },
    notes: Array.isArray(obj.notes) ? obj.notes : [],
  };
}

/* -----------------------------
   Helpers: sanitize callouts
------------------------------ */

function sanitizePayloadCallouts(
  payload: IGLPayload,
  allowed: string[],
  notes: string[],
) {
  const fixPosition = (pos: any): string => {
    const input = typeof pos === "string" ? pos : "";
    const fixed = resolveCalloutToAllowed(input, allowed);
    if (fixed) return fixed;
    if (input)
      notes.push(
        `Callout invalid nerecunoscut: "${input}" (l-am lăsat neschimbat).`,
      );
    return input;
  };

  const fixPlan = (plan: StrategyPlan, label: string) => {
    // Ensure structure
    if (!plan.quick) plan.quick = { buy: "", plan: "", fallback: "" };
    if (!Array.isArray(plan.layering)) plan.layering = [];
    if (!Array.isArray(plan.utility)) plan.utility = [];

    // Fix layering positions
    for (const ph of plan.layering) {
      if (!ph || !Array.isArray(ph.actions)) continue;
      for (const act of ph.actions) {
        if (!act) continue;
        const before = act.position;
        act.position = fixPosition(act.position);
        if (before && act.position && before !== act.position) {
          notes.push(
            `[${label}] corectat callout: "${before}" -> "${act.position}"`,
          );
        }
      }
    }

    // Fix utility positions
    for (const u of plan.utility) {
      if (!u) continue;
      const before = u.position;
      u.position = fixPosition(u.position);
      if (before && u.position && before !== u.position) {
        notes.push(
          `[${label}] corectat util callout: "${before}" -> "${u.position}"`,
        );
      }
    }
  };

  fixPlan(payload.strategies.recommended, "recommended");
  fixPlan(payload.strategies.safe, "safe");
  fixPlan(payload.strategies.risk, "risk");
}

/* -----------------------------
   Rendering + strategy object
------------------------------ */

function renderOne(label: string, plan: StrategyPlan): string {
  const lines: string[] = [];
  lines.push(`${label}: [${plan.decision}] ${plan.voice}`.trim());
  if (plan.quick?.buy) lines.push(`BUY: ${plan.quick.buy}`);
  if (plan.quick?.plan) lines.push(`PLAN: ${plan.quick.plan}`);
  if (plan.quick?.fallback) lines.push(`FALLBACK: ${plan.quick.fallback}`);

  // Optional: show 4 phases compact
  if (Array.isArray(plan.layering) && plan.layering.length) {
    for (const ph of plan.layering) {
      const acts = (ph.actions || [])
        .map(
          (a) =>
            `${a.player} ${a.verb} ${a.position}${a.note ? ` (${a.note})` : ""}`,
        )
        .join(" | ");
      if (acts) lines.push(`[Faza ${ph.phase}] ${acts}`);
    }
  }

  // Utilities
  if (Array.isArray(plan.utility) && plan.utility.length) {
    const u = plan.utility
      .slice(0, 8)
      .map(
        (x) =>
          `${x.player}: ${x.type} ${x.position}${x.purpose ? ` (${x.purpose})` : ""}`,
      )
      .join(" | ");
    if (u) lines.push(`UTIL: ${u}`);
  }

  return lines.join("\n");
}

function renderThreeStrategies(
  strategies: Record<StrategyType, StrategyPlan>,
  selected: StrategyType,
): string {
  const header = `SELECTED: ${selected.toUpperCase()}`;
  const rec = renderOne("RECOMMENDED", strategies.recommended);
  const safe = renderOne("SAFE", strategies.safe);
  const risk = renderOne("RISK", strategies.risk);
  return [header, "", rec, "\n---\n", safe, "\n---\n", risk].join("\n");
}

function buildStrategyObject(
  strategies: Record<StrategyType, StrategyPlan>,
  selected: StrategyType,
  map: string,
  side: Side,
) {
  const titleMap: Record<StrategyType, string> = {
    recommended: "Recommended Strategy",
    safe: "Safe Play",
    risk: "High Risk",
  };

  const toContent = (p: StrategyPlan) => ({
    voice: `[${p.decision}] ${p.voice}`.trim(),
    quick: {
      buy: p.quick?.buy || "",
      plan: p.quick?.plan || "",
      fallback: p.quick?.fallback || "",
    },
    layering: (p.layering || []).map((ph) => {
      const acts = (ph.actions || [])
        .map(
          (a) =>
            `[Faza ${ph.phase}] ${a.player} ${a.verb} ${a.position}${a.note ? ` (${a.note})` : ""}`,
        )
        .join(" | ");
      return acts;
    }),
    roles: {},
    utility: (p.utility || []).map(
      (u) =>
        `${u.player}: ${u.type} ${u.position}${u.purpose ? ` (${u.purpose})` : ""}`,
    ),
    triggers: [],
    win_conditions: [],
    failure_branches: [],
  });

  return {
    primary: {
      title: titleMap[selected],
      type: selected,
      map,
      side,
      content: toContent(strategies[selected]),
    },
    safer: {
      title: titleMap.safe,
      type: "safe",
      map,
      side,
      content: toContent(strategies.safe),
    },
    risk: {
      title: titleMap.risk,
      type: "risk",
      map,
      side,
      content: toContent(strategies.risk),
    },
    selected,
    source: "chat",
  };
}

/* -----------------------------
   Fallback (old behavior)
------------------------------ */

function buildFallbackStrategy(
  rawText: string,
  map: string,
  side: Side,
  strategyType: StrategyType,
) {
  return {
    primary: {
      title:
        strategyType === "safe"
          ? "Safe Play"
          : strategyType === "risk"
            ? "High Risk"
            : "Strategic Call",
      type: strategyType,
      map,
      side,
      content: {
        voice: rawText.split("\n")[0] || "",
        quick: {
          buy: extractBuy(rawText),
          plan: rawText,
          fallback: extractFallback(rawText),
        },
        layering: extractLayering(rawText),
        roles: {},
        utility: [],
        triggers: [],
        win_conditions: [],
        failure_branches: [],
      },
    },
    safer: null,
    risk: null,
    selected: strategyType,
    source: "chat",
  };
}

function extractBuy(text: string): string {
  const buyMatch = text.match(/BUY[:\s]+([^\n]+)/i);
  if (buyMatch) return buyMatch[1].trim();
  if (/\beco\b/i.test(text)) return "Eco (pistol only)";
  if (/\bforce\b/i.test(text)) return "Force buy";
  return "Standard buy";
}

function extractFallback(text: string): string {
  const fallbackMatch = text.match(/FALLBACK[:\s]+([^\n]+)/i);
  if (fallbackMatch) return fallbackMatch[1].trim();
  return "Regroup și trade";
}

function extractLayering(text: string): string[] {
  const stepMatches = text.match(/(?:^|\n)\s*\d+[\.\)]\s*([^\n]+)/g);
  if (stepMatches && stepMatches.length >= 2) {
    return stepMatches
      .map((s) => s.replace(/^\s*\d+[\.\)]\s*/, "").trim())
      .slice(0, 4);
  }
  return [];
}
