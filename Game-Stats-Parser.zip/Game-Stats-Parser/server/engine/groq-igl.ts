import Groq from "groq-sdk";
import { getCallouts } from "./cs2-callouts";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY || "" });

export type LobbyState = any;

type CallContent = {
  voice: string;
  quick: { buy: string; plan: string; fallback: string; drops?: string[] };
  layering: string[];
  roles: Record<string, string>;
  utility: string[];
  triggers: string[];
  win_conditions: string[];
  failure_branches: string[];
  notes?: string[];
};

type Call = {
  title: string;
  type: "primary" | "safe" | "risk";
  map: string;
  side: "T" | "CT";
  content: CallContent;
};

export type StrategyType = "recommended" | "safe" | "risk";

export async function generateIGLWithGroq({
  map,
  side,
  scoreUs,
  scoreThem,
  economyUs,
  economyThem,
  lobbyState,
  members,
  strategyType = "recommended",
}: {
  map: string;
  side: "T" | "CT";
  scoreUs: number;
  scoreThem: number;
  economyUs: string;
  economyThem: string;
  lobbyState: LobbyState;
  members: Array<{ id: number; username: string; faceitUsername?: string }>;
  strategyType?: StrategyType;
}): Promise<{ primary: Call | null; safer: Call | null; risk: Call | null; selected: StrategyType }> {
  const tendencies = lobbyState?.tendencies || {};
  const teamEcon = lobbyState?.team_economy || null;

  const playerNames = members.map((m) => m.username);
  const p1 = playerNames[0] || "P1";
  const p2 = playerNames[1] || "P2";
  const p3 = playerNames[2] || "P3";
  const p4 = playerNames[3] || "P4";
  const p5 = playerNames[4] || "P5";
  
  const diff = scoreUs - scoreThem;
  const mapCallouts = getCallouts(map);

  const typeDesc = strategyType === "recommended" 
    ? "RECOMANDATĂ (echilibrată)" 
    : strategyType === "safe" 
    ? "SAFE (pasivă, conservatoare)" 
    : "RISK (agresivă, high-risk)";

  // CT vs T specific examples
  const sideExamples = side === "CT" ? `
EȘTI PE CT (COUNTER-TERRORIST) - APĂRARE!
- Poziții de hold pe site-uri
- Rotații bazate pe info  
- Retake-uri când pierzi un site
- Crossfire și trade-uri defensive

EXEMPLE CT ${map}:
"${p1} și ${p2} anchor A, ${p3} mid info, ${p4} și ${p5} hold B. La contact A, ${p3} rotește din mid."
"Agresiv: ${p1} push pentru info, dacă moare ${p2} trade imediat."
"Retake B: ${p1} și ${p2} din CT, ${p3} market, util apoi entry together."` 
  : `
EȘTI PE T (TERRORIST) - ATAC!
- Execuții pe site-uri
- Entry + trade system
- Fake-uri și split-uri
- Post-plant positions

EXEMPLE T ${map}:
"A execute: ${p1} entry, ${p2} trade, smoke-uri site, ${p3} plant default."
"Split: ${p1}/${p2} main, ${p3}/${p4} alt entry, ${p5} lurk."
"Fake + Hit: Util pe A, rotiți rapid B."`;

  const prompt = `Ești IGL profesionist CS2. Generează o strategie ${typeDesc} în ROMÂNĂ.

═══════════════════════════════════════════════════════════
HARTA: ${map.toUpperCase()} | SIDE: ${side.toUpperCase()}
SCOR: ${scoreUs}-${scoreThem} (${diff >= 0 ? "+" : ""}${diff})
ECONOMIA: Noi=${economyUs}, Ei=${economyThem}
JUCĂTORI: ${p1}, ${p2}, ${p3}, ${p4}, ${p5}
═══════════════════════════════════════════════════════════

${sideExamples}

═══════════════════════════════════════════════════════════
CALLOUT-URI VALIDE ${map.toUpperCase()} (DOAR ACESTEA!):
═══════════════════════════════════════════════════════════
${mapCallouts}

TENDINȚE INAMICE:
${tendencies.aggressive ? "- Agresivi: flash + trade" : ""}
${tendencies.rotate_fast ? "- Rotesc rapid: fake util, hit tardiv" : ""}
${tendencies.stack_frequent ? "- Stack: probe 2-1-2" : ""}
${tendencies.mid_focus ? "- Mid focus: control sau evită" : ""}
${tendencies.awp_aggressive ? "- AWP agresiv: flash sau evită" : ""}
${tendencies.late_rotate ? "- Late rotate: exec rapid" : ""}

Răspunde cu JSON (fără markdown):
{
  "strategy": {
    "voice": "Call vocal scurt pentru echipă în română",
    "quick": {
      "buy": "${p1}: [armă+util], ${p2}: [armă+util], ${p3}: [armă+util], ${p4}: [armă+util], ${p5}: [armă+util]",
      "plan": "Planul în 2 propoziții",
      "fallback": "Ce facem dacă nu merge"
    },
    "layering": [
      "[Setup] ${p1} se duce [POZIȚIE], ${p2} și ${p3} merg [POZIȚIE]...",
      "[Contact] ${p4} dă smoke [POZIȚIE], ${p5} flashează...",
      "[Execute/React] Descriere acțiuni principale...",
      "[End] Post-plant/Retake: poziții finale..."
    ],
    "roles": {"Entry": "${p1}", "Trade": "${p2}", "Support": "${p3}", "Lurk": "${p4}", "Anchor": "${p5}"},
    "utility": ["${p1}: smoke [poz], flash [poz]", "${p2}: smoke [poz], molly [poz]"]
  }
}

IMPORTANT:
1. Folosește DOAR poziții din lista pentru ${map.toUpperCase()}!
2. Fiecare jucător menționat PE NUME
3. Tactici specifice pentru ${side} - NU amesteca CT cu T!`;

  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 2048,
      temperature: 0.8,
    });

    const text = response.choices[0]?.message?.content || "";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON in response");
    }

    const data = JSON.parse(jsonMatch[0]);
    const variant = data.strategy;

    const titleMap: Record<StrategyType, string> = {
      recommended: "Recommended Strategy",
      safe: "Safe Play",
      risk: "High Risk",
    };

    const typeMap: Record<StrategyType, "primary" | "safe" | "risk"> = {
      recommended: "primary",
      safe: "safe",
      risk: "risk",
    };

    const call: Call = {
      title: titleMap[strategyType],
      type: typeMap[strategyType],
      map,
      side,
      content: {
        voice: variant.voice || "",
        quick: {
          buy: variant.quick?.buy || "",
          plan: variant.quick?.plan || "",
          fallback: variant.quick?.fallback || "",
          drops: variant.quick?.drops,
        },
        layering: variant.layering || [],
        roles: variant.roles || {},
        utility: variant.utility || [],
        triggers: variant.triggers || [],
        win_conditions: variant.win_conditions || [],
        failure_branches: variant.failure_branches || [],
        notes: variant.notes,
      },
    };

    return {
      primary: strategyType === "recommended" ? call : null,
      safer: strategyType === "safe" ? call : null,
      risk: strategyType === "risk" ? call : null,
      selected: strategyType,
    };
  } catch (error) {
    console.error("Groq IGL error:", error);
    throw error;
  }
}
