export type MapZone = "A" | "B" | "MID" | "SPAWN" | "CT";

export type CalloutsByZone = {
  SPAWN: string[];
  MID: string[];
  A: string[];
  B: string[];
  CT: string[];
};

export const CS2_CALLOUTS_ZONES: Record<string, CalloutsByZone> = {
  Mirage: {
    SPAWN: ["T Spawn"],
    MID: [
      "Top Mid",
      "Mid",
      "Lower Mid",
      "Underpass",
      "Window",
      "Short",
      "Connector",
      "Ladder Room",
    ],
    A: [
      "A Ramp",
      "Tetris",
      "Palace",
      "Balcony",
      "Default A",
      "Triple",
      "Firebox",
      "Ninja",
      "Stairs",
      "Jungle",
      "Ticket",
      "Sandwich",
    ],
    B: [
      "B Apartments",
      "Bench",
      "Default B",
      "Pillar",
      "Back Site",
      "Van",
      "Market",
      "Kitchen",
      "Short B",
    ],
    CT: ["CT Spawn"],
  },

  Dust2: {
    SPAWN: ["T Spawn"],
    MID: ["Top Mid", "Suicide", "Mid", "Mid Doors", "Xbox", "Short", "CT Mid"],
    A: [
      "Long Doors",
      "Long",
      "Blue",
      "Pit",
      "Car",
      "A Ramp",
      "Plat",
      "Goose",
      "Default A",
    ],
    B: [
      "Upper Tunnels",
      "Lower Tunnels",
      "B Doors",
      "Window",
      "Default B",
      "Back Site",
      "Car B",
    ],
    CT: ["CT Spawn"],
  },

  // maps rest: keep them simple for now (you can refine later)
  Anubis: {
    SPAWN: ["T Spawn"],
    MID: ["Mid", "Bridge", "Water", "Connector"],
    A: ["A Main", "Temple", "Heaven A", "Default A", "Pillar A"],
    B: ["B Main", "Ruins", "Heaven B", "Default B", "Back Site"],
    CT: ["CT Spawn"],
  },

  Ancient: {
    SPAWN: ["T Spawn"],
    MID: ["Mid", "Donut", "Cave", "Mid Window"],
    A: ["A Main", "Temple", "Default A", "Dice", "Heaven A"],
    B: ["B Ramp", "Default B", "Back Site", "Dark"],
    CT: ["CT Spawn"],
  },

  Overpass: {
    SPAWN: ["T Spawn"],
    MID: ["Playground", "Fountain", "Bathrooms", "Connector"],
    A: ["A Long", "Bank", "Truck", "Default A", "Heaven A"],
    B: ["Monster", "Water", "Short B", "Default B", "Pillar", "Back Site"],
    CT: ["CT Spawn"],
  },

  Inferno: {
    SPAWN: ["T Spawn"],
    MID: ["T Ramp", "Mid", "Top Mid", "Boiler", "Arch", "Library"],
    A: [
      "Second Mid",
      "Balcony",
      "Apartments",
      "A Long",
      "Pit",
      "Default A",
      "Graveyard",
    ],
    B: [
      "Banana",
      "Car",
      "Logs",
      "Construction",
      "Coffins",
      "Dark",
      "Default B",
      "Back Site",
    ],
    CT: ["CT Spawn"],
  },

  Train: {
    SPAWN: ["T Spawn"],
    MID: ["T Con", "Pop Dog", "Hell"],
    A: ["A Main", "Ivy", "Default A", "Heaven A", "Hell A"],
    B: ["B Hall", "Upper B", "Lower B", "Default B", "Back Site", "Headshot"],
    CT: ["CT Spawn"],
  },

  Nuke: {
    SPAWN: ["T Spawn", "T Roof", "Lobby"],
    MID: ["Outside", "Secret", "Silo", "Garage"],
    A: [
      "A Main",
      "Squeaky",
      "Hut",
      "Default A",
      "Heaven A",
      "Hell A",
      "Rafters",
    ],
    B: ["B Ramp", "Toxic", "Control Room", "Default B", "Back Site", "Vents"],
    CT: ["CT Spawn"],
  },
};

function normalizeMapName(map: string) {
  const m = String(map || "").trim();
  return CS2_CALLOUTS_ZONES[m] ? m : "Mirage";
}

/**
 * Returnează callout-urile ca text (pentru prompt) + listă allowed.
 * Dacă dai focus, filtrează callout-urile pe zona aleasă + spawn/ct + mid (opțional).
 */
export function getCallouts(
  map: string,
  focus?: "A" | "B" | "MID",
): { text: string; allowed: string[]; zones: CalloutsByZone } {
  const key = normalizeMapName(map);
  const zones = CS2_CALLOUTS_ZONES[key];

  // Allowed list: dacă ai focus, nu mai permiți callout-uri din cealaltă parte
  const allowedSet = new Set<string>();
  zones.SPAWN.forEach((x) => allowedSet.add(x));
  zones.CT.forEach((x) => allowedSet.add(x));

  if (!focus) {
    [...zones.MID, ...zones.A, ...zones.B].forEach((x) => allowedSet.add(x));
  } else if (focus === "MID") {
    zones.MID.forEach((x) => allowedSet.add(x));
    // la MID mai lași și 1-2 din A/B ca “transitions” dacă vrei:
    ["Connector", "Window", "Short"].forEach((x) => allowedSet.add(x));
  } else if (focus === "A") {
    zones.A.forEach((x) => allowedSet.add(x));
    // permiți doar câteva “legături” spre A
    ["Top Mid", "Mid", "Connector", "Jungle", "Stairs"].forEach((x) =>
      allowedSet.add(x),
    );
  } else if (focus === "B") {
    zones.B.forEach((x) => allowedSet.add(x));
    // permiți doar câteva “legături” spre B
    ["Top Mid", "Mid", "Window", "Kitchen", "Market"].forEach((x) =>
      allowedSet.add(x),
    );
  }

  const allowed = Array.from(allowedSet);

  const toLine = (title: string, arr: string[]) =>
    `${title}: ${arr.join(", ")}`;
  const text = [
    `POZIȚII ${key.toUpperCase()}:`,
    toLine("SPAWN", zones.SPAWN),
    toLine("MID", zones.MID),
    toLine("A", zones.A),
    toLine("B", zones.B),
    toLine("CT", zones.CT),
    focus
      ? `FOCUS: ${focus} (folosește doar callout-uri relevante focusului)`
      : "",
  ]
    .filter(Boolean)
    .join("\n");

  return { text, allowed, zones };
}
