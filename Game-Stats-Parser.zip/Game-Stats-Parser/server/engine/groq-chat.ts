import Groq from "groq-sdk";
import { getCallouts } from "./cs2-callouts";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY || "" });

export type LobbyState = any;

type CallContent = {
  voice: string;
  quick: { buy: string; plan: string; fallback: string; drops?: string[] };
  layering: string[];
  roles: Record<string, string>;
  utility: string[];
  triggers: string[];
  win_conditions: string[];
  failure_branches: string[];
  notes?: string[];
};

type Call = {
  title: string;
  type: "primary" | "safe" | "risk";
  map: string;
  side: "T" | "CT";
  content: CallContent;
};

export type StrategyType = "recommended" | "safe" | "risk";

type GroqPlan = {
  voice?: string;
  quick?: { buy?: string; plan?: string; fallback?: string; drops?: string[] };
  layering?: string[];
  roles?: Record<string, string>;
  utility?: string[];
  triggers?: string[];
  win_conditions?: string[];
  failure_branches?: string[];
  notes?: string[];
};

type GroqPayload = {
  selected?: StrategyType;
  strategies?: Record<StrategyType, GroqPlan>;
  // fallback (dacă modelul întoarce vechiul format)
  strategy?: GroqPlan;
  notes?: string[];
};

export async function generateIGLWithGroq({
  map,
  side,
  scoreUs,
  scoreThem,
  economyUs,
  economyThem,
  lobbyState,
  members,
  strategyType = "recommended",
}: {
  map: string;
  side: "T" | "CT";
  scoreUs: number;
  scoreThem: number;
  economyUs: string;
  economyThem: string;
  lobbyState: LobbyState;
  members: Array<{ id: number; username: string; faceitUsername?: string }>;
  strategyType?: StrategyType;
}): Promise<{
  primary: Call | null;
  safer: Call | null;
  risk: Call | null;
  selected: StrategyType;
}> {
  const tendencies = lobbyState?.tendencies || {};
  const teamEcon = lobbyState?.team_economy || null;

  const playerNames = members.map((m) => m.username);
  const p1 = playerNames[0] || "P1";
  const p2 = playerNames[1] || "P2";
  const p3 = playerNames[2] || "P3";
  const p4 = playerNames[3] || "P4";
  const p5 = playerNames[4] || "P5";

  const diff = scoreUs - scoreThem;

  // --- Callouts: make them strict
  // alegem focus în funcție de strategieType + side
  // (poți face ceva mai smart, dar asta deja taie nonsensul)
  const focus =
    side === "T"
      ? strategyType === "safe"
        ? "MID"
        : "A"
      : strategyType === "safe"
        ? "MID"
        : "B"; // exemplu

  const { text: mapCalloutsText, allowed: allowedCallouts } = getCallouts(map);

  // fallback minimal, dar acum NU mai redeclarăm "allowed"
  const allowedFinal =
    allowedCallouts.length >= 10
      ? allowedCallouts
      : ["T Spawn", "Mid", "A Ramp", "Palace", "A Site", "B Site", "CT Spawn"];

  const typeDesc =
    strategyType === "recommended"
      ? "RECOMANDATĂ (echilibrată)"
      : strategyType === "safe"
        ? "SAFE (pasivă, conservatoare)"
        : "RISK (agresivă, high-risk)";

  // CT vs T specific examples (kept, but shorter and cleaner)
  const sideExamples =
    side === "CT"
      ? `
EȘTI PE CT (APĂRARE):
- Hold pe site-uri, info, rotate, retake, crossfire.
Exemple:
- "2-1-2: ${p1}+${p2} A, ${p3} Mid info, ${p4}+${p5} B"
- "Info play: un push controlat pentru info + trade"`
      : `
EȘTI PE T (ATAC):
- Map control, execute, entry+trade, plant, post-plant.
Exemple:
- "Exec A: ${p1} entry, ${p2} trade, util, plant default"
- "Split: 2 dintr-o intrare, 2 din alta, 1 lurk"`;

  // Tendencies to bullets (only ones enabled)
  const tendencyBullets = [
    tendencies.aggressive
      ? "- Agresivi: pregătește anti-rush (flash + trade / util delay)"
      : "",
    tendencies.rotate_fast
      ? "- Rotesc rapid: fake util + hit târziu / repozition"
      : "",
    tendencies.stack_frequent
      ? "- Stack: probe + punish (default/late exec)"
      : "",
    tendencies.mid_focus
      ? "- Mid focus: contest control sau evită și lovește extremități"
      : "",
    tendencies.awp_aggressive
      ? "- AWP agresiv: flash/avoid, trade pe peek"
      : "",
    tendencies.late_rotate
      ? "- Late rotate: exec rapid + plant + post-plant"
      : "",
    tendencies.util_heavy
      ? "- Util heavy: joacă spread, bait util, re-hit"
      : "",
  ]
    .filter(Boolean)
    .join("\n");

  // Better prompt: force 3 strategies + keep callouts canonical
  const prompt = `
Ești un IGL de elită în CS2: calm, clar, decisiv, cu comunicare scurtă și structură.
Vorbești DOAR în română (jargon CS permis: smoke/flash/moly, trade, entry, lurk).
Răspunzi DOAR cu JSON valid (fără markdown, fără text extra).

PRINCIPII DE IGL (obligatorii):
- One-voice: comenzi scurte, fără “filler”. Nu folosi formulări robotice gen „pe posturi”.
- Control mid-round: iei decizii pe info, nu pe “poezie”.
- Comunicarea trebuie să rămână calmă și orientată pe info + riscuri. (fără panică)

CONTEXT:
HARTA: ${map.toUpperCase()}
SIDE: ${side.toUpperCase()}
SCOR: ${scoreUs}-${scoreThem} (diferență: ${diff >= 0 ? "+" : ""}${diff})
ECONOMIA: Noi=${economyUs}, Ei=${economyThem}
JUCĂTORI: ${p1}, ${p2}, ${p3}, ${p4}, ${p5}
TENDINȚE INAMICE (dacă există): ${JSON.stringify(tendencies || {}, null, 2)}
TEAM ECON (dacă există): ${teamEcon ? JSON.stringify(teamEcon) : "n/a"}

CALLOUT VOCABULAR (SINGURELE poziții permise în text; scrie EXACT așa, case-sensitive):
${JSON.stringify(allowedFinal, null, 2)}

------------------------------------------------------------
IDEA BANK “PRO-STYLE” (NU copia literal; folosește ca inspirație).
Alege un ARHETIP diferit pentru FIECARE strategie (recommended/safe/risk).

Dacă SIDE = T, alege din:
1) DEFAULT_3_LANE_LATE_EXEC:
   - start default pe 3 lane (A presence + Mid info + B presence)
   - la ~0:45 alegi exec pe site-ul mai slab / unde ai info
2) MID_CONTROL_CONNECTOR_SPLIT_A:
   - iei Mid -> Connector, apoi split A (Ramp + Palace/Connector)
3) RAMP_PRESSURE_PALACE_POP:
   - Ramp pressure ține rotările, Palace pop intră pe timing cu flash
4) B_APPS_CONTROL_SPLIT_SHORT:
   - controlezi B Apartments, apoi split (B Apartments + Short B / Market)
5) FAKE_ONE_SIDE_TO_OTHER:
   - arăți util pe o parte, finalizezi pe cealaltă pe timing (~0:50)
6) CONTACT_PUNISH:
   - 1-2 jucători fac contact pentru info, restul țin spacing și punish
7) ANTI_ECO_PROTOCOL:
   - grupat, trade strict, clear unghiuri, util minimal dar disciplinat

Dacă SIDE = CT, alege din:
1) STANDARD_2_1_2_INFO:
   - setup standard, 1 info play controlat (nu aruncat), restul ready de trade
2) MID_DENY_ROTATE:
   - blochezi Mid cu util, rotator pregătit să ajute A/B
3) EXTREMITY_TRAP:
   - lași “bait” controlat, apoi trap cu crossfire + retake
4) FAST_STACK_READ:
   - dacă ai read (tendințe), stack devreme + plan de retake
5) RETAKE_PROTOCOL:
   - cedezi control, dar ai retake cu util + timing + 2-3 împreună

------------------------------------------------------------
TASK:
Generează 3 strategii COMPLET DIFERITE (alt ARHETIP, alt focus, alt tempo):
- recommended = structurată, echilibrată, cea mai “solidă”
- safe = low risk: info-first, decizie târzie, minimizezi duelurile proaste
- risk = high tempo: decizie timpurie, punish/pace mare (dar încă logic)

IMPORTANT: 
- Nu ai voie să repeți același focus (A/B/MID) la toate 3.
- Nu ai voie să repeți același ARHETIP la toate 3.
- “Mid control” nu apare la START; e realist abia după ~0:25–0:40.
- Max 1 lurk per strategie. Lurk-ul trebuie să aibă scop: taie rotate/flank și are “când intră”.

FORMAT OUTPUT STRICT (JSON):
{
  "selected": "recommended" | "safe" | "risk",
  "strategies": {
    "recommended": {
      "voice": "...",
      "quick": {
        "buy": "...",
        "plan": "FOCUS: A|B|MID. SPLIT: ... . CONDIȚIE GO: ... .",
        "fallback": "..."
      },
      "layering": [
        "START (spawn): ...",
        "MID ROUND (~0:35): ...",
        "EXEC (~0:50): ...",
        "POST (~1:10): ..."
      ],
      "roles": { ... },
      "utility": [
        "P?: SMOKE -> CALL0UT (scop)",
        "P?: FLASH -> CALL0UT (scop)"
      ],
      "triggers": [
        "Dacă ..., atunci ...",
        "Dacă ..., atunci ..."
      ],
      "win_conditions": ["...", "..."],
      "failure_branches": ["...", "..."],
      "notes": ["ARHETIP: ...", "De ce funcționează: ..."]
    },
    "safe": { ... },
    "risk": { ... }
  },
  "notes": ["optional"]
}

REGULI CRITICE:
1) În layering/utility folosește DOAR callout-uri din listă (case-sensitive). Nu inventa.
2) Layering trebuie să fie jucabil: entry+trade explicite (cine intră primul, cine dă trade).
3) Utility trebuie să aibă ORDINE + scop (blochează AWP, izolează Jungle, etc.), nu spam.
4) Dacă focus e A, nu folosi callout-uri B (Van/Bench/Market etc.) decât dacă explici clar “fake” și timing.
5) Evită fraze goale (“pe posturi”, “poziție de rezervă”). Spune concret: “ține trade”, “taie rotate”, “clear Ninja”.
6) Pistol/eco: util limitat, exec simplu, spacing + trade; nu planuri care cer 4 smokes perfecte.
7) Fiecare strategie trebuie să fie diferită în mod vizibil (alt focus + alt split + alt tempo + alt trigger).
`.trim();

  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [{ role: "user", content: prompt }],
      // JSON mode (best effort)
      ...({ response_format: { type: "json_object" } } as any),
      max_tokens: 1600,
      temperature: 0.35,
      ...({ seed: 7 } as any),
    });

    const text = response.choices[0]?.message?.content || "";

    // Parse robustly
    const payload: GroqPayload =
      safeJsonParse(text) ?? safeJsonParse(extractJsonObject(text)) ?? {};

    // Coerce into 3 strategies even if model returned old shape
    const coerced = coerceToThree(payload);

    // Sanitize callouts in the final strings (alias → canonical) and flag unknowns
    const notes: string[] = [];
    sanitizeTextCallouts(coerced, allowedFinal, notes);

    const selected: StrategyType =
      strategyType || coerced.selected || "recommended";

    const titleMap: Record<StrategyType, string> = {
      recommended: "Recommended Strategy",
      safe: "Safe Play",
      risk: "High Risk",
    };

    const typeMap: Record<StrategyType, "primary" | "safe" | "risk"> = {
      recommended: "primary",
      safe: "safe",
      risk: "risk",
    };

    const toCall = (st: StrategyType): Call => {
      const v = coerced.strategies[st];

      return {
        title: titleMap[st],
        type: typeMap[st],
        map,
        side,
        content: {
          voice: v.voice || "",
          quick: {
            buy: v.quick?.buy || "",
            plan: v.quick?.plan || "",
            fallback: v.quick?.fallback || "",
            drops: v.quick?.drops,
          },
          layering: v.layering || [],
          roles: v.roles || {},
          utility: v.utility || [],
          triggers: v.triggers || [],
          win_conditions: v.win_conditions || [],
          failure_branches: v.failure_branches || [],
          notes: [...(v.notes || []), ...(coerced.notes || []), ...notes].slice(
            0,
            12,
          ),
        },
      };
    };

    const rec = toCall("recommended");
    const safe = toCall("safe");
    const risk = toCall("risk");

    return {
      primary: rec, // always return all 3; UI can choose
      safer: safe,
      risk: risk,
      selected,
    };
  } catch (error) {
    console.error("Groq IGL error:", error);
    throw error;
  }
}

/* -----------------------------
   JSON helpers
------------------------------ */

function safeJsonParse(text: string): any | null {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function extractJsonObject(text: string): string {
  const raw = String(text || "");
  const match = raw.match(/\{[\s\S]*\}/);
  return match ? match[0] : "{}";
}

/* -----------------------------
   Coercion to 3 strategies
------------------------------ */

function emptyPlan(): GroqPlan {
  return {
    voice: "Nu am putut genera plan complet; joacă default și caută info.",
    quick: { buy: "", plan: "", fallback: "" },
    layering: [],
    roles: {},
    utility: [],
    triggers: [],
    win_conditions: [],
    failure_branches: [],
    notes: ["fallback plan"],
  };
}

function coerceToThree(payload: GroqPayload): {
  selected: StrategyType;
  strategies: Record<StrategyType, GroqPlan>;
  notes?: string[];
} {
  // If model returned old format: { strategy: {...} }
  if (!payload?.strategies && payload?.strategy) {
    return {
      selected: payload.selected || "recommended",
      strategies: {
        recommended: payload.strategy,
        safe: emptyPlan(),
        risk: emptyPlan(),
      },
      notes: [
        ...(payload.notes || []),
        "Model a returnat format vechi; am adaptat în 3 strategii.",
      ],
    };
  }

  const s = payload?.strategies || ({} as any);

  return {
    selected: (payload.selected as StrategyType) || "recommended",
    strategies: {
      recommended: s.recommended || emptyPlan(),
      safe: s.safe || emptyPlan(),
      risk: s.risk || emptyPlan(),
    },
    notes: payload.notes || [],
  };
}

/* -----------------------------
   Callout extraction + sanitization
------------------------------ */

function extractCalloutNames(calloutsText: string): string[] {
  const lines = String(calloutsText || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const names = new Set<string>();

  for (const line of lines) {
    const clean = line.replace(/```/g, "").trim();
    if (/^[-=]{3,}$/.test(clean)) continue;

    // Strip bullets / numbering
    let l = clean.replace(/^\s*[-*•]+\s*/, "");
    l = l.replace(/^\s*\d+[\.\)]\s*/, "");

    // If "X: a, b, c" keep RHS
    if (l.includes(":")) {
      const parts = l.split(":");
      if (parts.length >= 2) l = parts.slice(1).join(":").trim();
    }

    // Remove description part
    l = l.split(" – ")[0].split(" - ")[0].trim();

    // split possible lists
    const candidates = l.includes(",") ? l.split(",") : [l];
    for (const c of candidates) {
      const name = c.trim();
      if (!name) continue;
      if (name.length > 40) continue;
      if (!/[a-zA-ZăîâșțĂÎÂȘȚ]/.test(name)) continue;
      // skip generic headers
      if (/^(t side|ct side|mid|a site|b site|t spawn|ct spawn)$/i.test(name))
        continue;

      names.add(name);
    }
  }

  const arr = Array.from(names);
  arr.sort((a, b) => a.length - b.length || a.localeCompare(b));
  return arr;
}

function normalizeCallout(s: string): string {
  return String(s || "")
    .toLowerCase()
    .replace(/[’'`"]/g, "")
    .replace(/[\(\)\[\]\{\}]/g, "")
    .replace(/[^a-z0-9ăîâșț\/\s-]/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

function resolveCalloutToAllowed(
  input: string,
  allowed: string[],
): string | null {
  if (!input) return null;
  if (allowed.includes(input)) return input;

  const normAllowed = new Map<string, string>();
  for (const a of allowed) normAllowed.set(normalizeCallout(a), a);

  const norm = normalizeCallout(input);
  if (normAllowed.has(norm)) return normAllowed.get(norm)!;

  const aliasRules: Array<{ re: RegExp; wants: string[] }> = [
    { re: /\bconn\b|\bconnector\b/i, wants: ["Connector", "Conn"] },
    {
      re: /\bapps?\b|\bapts?\b|\bapartments\b/i,
      wants: ["Apartments", "Aps", "Apps", "B Apartments"],
    },
    {
      re: /\bcat\b|\bcatwalk\b|\bshort\b/i,
      wants: ["Short", "Catwalk", "Cat"],
    },
    { re: /\bticket\b|\bbooth\b/i, wants: ["Ticket", "Booth"] },
    { re: /\bwindow\b/i, wants: ["Window", "Mid Window"] },
    { re: /\bdefault\b/i, wants: ["Default"] },
    { re: /\bct\s*spawn\b|\bctspawn\b/i, wants: ["CT Spawn"] },
    { re: /\bt\s*spawn\b|\btspawn\b/i, wants: ["T Spawn"] },
  ];

  for (const rule of aliasRules) {
    if (!rule.re.test(input)) continue;
    for (const want of rule.wants) {
      const found = allowed.find(
        (a) => normalizeCallout(a) === normalizeCallout(want),
      );
      if (found) return found;
      const found2 = allowed.find((a) =>
        normalizeCallout(a).includes(normalizeCallout(want)),
      );
      if (found2) return found2;
    }
  }

  // substring fallback
  for (const [na, canonical] of Array.from(normAllowed.entries())) {
    if (na.includes(norm) || norm.includes(na)) return canonical;
  }

  return null;
}

// We can't force the model to output callout IDs here because your schema uses plain strings.
// But we can sanitize by replacing alias-like tokens with canonical callouts *when possible*.
function sanitizeTextCallouts(
  coerced: { strategies: Record<StrategyType, GroqPlan>; notes?: string[] },
  allowed: string[],
  notes: string[],
) {
  const fixLine = (line: string): string => {
    let out = String(line || "");

    // If the model wrote something like [POZIȚIE] keep but try to remove it
    out = out.replace(/\[POZIȚIE[^\]]*\]/gi, "");

    // Replace a few common alias tokens with canonical ones if exist
    const replacements: Array<{ re: RegExp; sample: string }> = [
      { re: /\bconn\b/gi, sample: "Connector" },
      { re: /\baps\b|\bapps\b/gi, sample: "Apartments" },
      { re: /\bcat\b|\bcatwalk\b/gi, sample: "Short" },
      { re: /\bticket\b|\bbooth\b/gi, sample: "Ticket" },
    ];

    for (const r of replacements) {
      if (!r.re.test(out)) continue;
      const resolved = resolveCalloutToAllowed(r.sample, allowed);
      if (resolved) out = out.replace(r.re, resolved);
    }

    return out.trim().replace(/\s+/g, " ");
  };

  const scanForUnknown = (line: string) => {
    // not perfect, but catches obvious invented words like "Backsite" when not allowed
    const tokens = line.split(/[\s,;:.]+/).filter(Boolean);
    for (const t of tokens) {
      // If token looks like a callout word but isn't in allowed list (case-insensitive)
      if (t.length >= 4 && /[A-Za-z]/.test(t)) {
        const normalized = normalizeCallout(t);
        const ok = allowed.some((a) => normalizeCallout(a) === normalized);
        if (
          !ok &&
          /(backsite|stairs|jungle|palace|ticket|apps|connector|catwalk|window|market)/i.test(
            t,
          )
        ) {
          notes.push(
            `Posibil callout nepermis: "${t}" (verifică lista pentru harta ${coerced ? "" : ""})`,
          );
        }
      }
    }
  };

  (Object.keys(coerced.strategies) as StrategyType[]).forEach((k) => {
    const plan = coerced.strategies[k];

    if (Array.isArray(plan.layering)) {
      plan.layering = plan.layering.map((l) => {
        const fixed = fixLine(l);
        scanForUnknown(fixed);
        return fixed;
      });
    }

    if (Array.isArray(plan.utility)) {
      plan.utility = plan.utility.map((l) => {
        const fixed = fixLine(l);
        scanForUnknown(fixed);
        return fixed;
      });
    }
  });
}
/* -----------------------------
   Chat endpoint helper
------------------------------ */

type ChatInput = {
  map: string;
  side: "CT" | "T" | string;
  tendencies: Record<string, any>;
  message: string;
  history: Array<{ role: "user" | "assistant" | "system"; content: string }>;
  players: Array<any>;
  strategyType: "recommended" | "safe" | "risk" | string;
  economy: any;
  playerPositions?: any;
};

// Heuristic: decide dacă user cere plan/strategie
function wantsStrategy(text: string): boolean {
  const t = String(text || "").toLowerCase();
  return (
    t.includes("strategie") ||
    t.includes("plan") ||
    t.includes("call") ||
    t.includes("exec") ||
    t.includes("setup") ||
    t.includes("push") ||
    t.includes("rush") ||
    t.includes("default") ||
    t.includes("retake") ||
    t.includes("pistol") ||
    t.includes("pistoal") ||
    t.includes("tero") ||
    t.includes("t ") ||
    t.includes("ct") ||
    t.includes("runda") ||
    t.includes("eco") ||
    t.includes("full buy")
  );
}

/**
 * Chat conversational: întoarce răspuns text + opțional o strategie structurată.
 * Endpoint-ul /api/ai/chat se așteaptă la { response, strategy? }.
 */
export async function chatWithIGL(input: ChatInput): Promise<{
  response: string;
  strategy?: any;
}> {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) throw new Error("Missing GROQ_API_KEY");

  // IMPORTANT: evităm instanța globală creată cu key "".
  // (la import-time poate fi goală, și uneori produce comportamente ciudate)
  const localGroq = new Groq({ apiKey });

  const map = input.map || "Mirage";
  const side = (input.side || "CT") as "CT" | "T";
  const tendencies = input.tendencies || {};
  const players = input.players || [];
  const economy = input.economy || {};
  const message = input.message || "";

  // Construim un system prompt scurt, orientat pe IGL
  const system = `
Ești un asistent IGL de CS2. Răspunzi DOAR în română.
Fii scurt, practic, pe bullet points când e cazul.
Dacă user cere un call de rundă: dă un plan în pași (setup -> mid-round -> exec -> fallback).
HARTA: ${map}
SIDE: ${side}
TENDINȚE: ${JSON.stringify(tendencies)}
PLAYERS: ${JSON.stringify(players)}
ECONOMY: ${JSON.stringify(economy)}
${input.playerPositions ? "POZIȚII JUCĂTORI: " + JSON.stringify(input.playerPositions) : ""}
`.trim();

  // păstrăm ultimele mesaje ca context (fără system din history)
  const history = (input.history || [])
    .filter((m) => m && m.role && m.content)
    .slice(-10)
    .map((m) => ({
      role: (m.role === "system" ? "assistant" : m.role) as
        | "user"
        | "assistant",
      content: m.content,
    }));

  // 1) Răspuns conversațional
  const completion = await localGroq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    messages: [
      { role: "system", content: system },
      ...history,
      { role: "user", content: message },
    ],
    temperature: 0.6,
    max_tokens: 600,
  });

  const response =
    completion.choices?.[0]?.message?.content?.trim() ||
    "N-am reușit să generez un răspuns. Mai încearcă o dată.";

  // 2) Dacă user chiar cere strategie, generăm și strategia structurată (opțional)
  if (wantsStrategy(message)) {
    // încercăm să derivăm parametri minimi
    // (score/economy pot lipsi; punem fallback)
    const members = players.map((p: any, idx: number) => ({
      id: Number(p.id ?? idx + 1),
      username: String(p.username ?? p.name ?? `P${idx + 1}`),
      faceitUsername: p.faceitUsername,
    }));

    const strategyType =
      (input.strategyType as any) === "safe" ||
      (input.strategyType as any) === "risk"
        ? (input.strategyType as any)
        : "recommended";

    try {
      const out = await generateIGLWithGroq({
        map,
        side: side as "CT" | "T",
        scoreUs: Number(economy?.scoreUs ?? 0),
        scoreThem: Number(economy?.scoreThem ?? 0),
        economyUs: String(economy?.economyUs ?? "full"),
        economyThem: String(economy?.economyThem ?? "full"),
        lobbyState: { tendencies },
        members,
        strategyType,
      });

      return {
        response,
        strategy: {
          primary: out.primary,
          safer: out.safer,
          risk: out.risk,
          selected: out.selected,
          source: "groq",
        },
      };
    } catch (e) {
      // dacă strategia pică, măcar chat-ul rămâne ok
      console.error("Strategy generation inside chat failed:", e);
      return { response };
    }
  }

  return { response };
}
