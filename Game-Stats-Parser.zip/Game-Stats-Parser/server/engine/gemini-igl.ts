import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export type LobbyState = any;

type CallContent = {
  voice: string;
  quick: { buy: string; plan: string; fallback: string; drops?: string[] };
  layering: string[];
  roles: Record<string, string>;
  utility: string[];
  triggers: string[];
  win_conditions: string[];
  failure_branches: string[];
  notes?: string[];
};

type Call = {
  title: string;
  type: "primary" | "safe" | "risk";
  map: string;
  side: "T" | "CT";
  content: CallContent;
};

export type StrategyType = "recommended" | "safe" | "risk";

export async function generateIGLWithGemini({
  map,
  side,
  scoreUs,
  scoreThem,
  economyUs,
  economyThem,
  lobbyState,
  members,
  strategyType = "recommended",
}: {
  map: string;
  side: "T" | "CT";
  scoreUs: number;
  scoreThem: number;
  economyUs: string;
  economyThem: string;
  lobbyState: LobbyState;
  members: Array<{ id: number; username: string; faceitUsername?: string }>;
  strategyType?: StrategyType;
}): Promise<{ primary: Call | null; safer: Call | null; risk: Call | null; selected: StrategyType }> {
  const tendencies = lobbyState?.tendencies || {};
  const teamEcon = lobbyState?.team_economy || null;

  const playerNames = members.map((m) => m.username).join(", ") || "P1, P2, P3, P4, P5";
  const diff = scoreUs - scoreThem;

  const typeDesc = strategyType === "recommended" 
    ? "RECOMANDAT (balansat, cel mai bun pentru situație)" 
    : strategyType === "safe" 
    ? "SAFE PLAY (pasiv, conservator, minimizează riscul)" 
    : "HIGH RISK (agresiv, rapid, all-in)";

  const prompt = `Ești un IGL profesionist de CS2. Generează O SINGURĂ strategie de tip ${typeDesc} pentru următoarea situație:

MAP: ${map}
SIDE: ${side}
SCOR: ${scoreUs}-${scoreThem} (${diff >= 0 ? "+" : ""}${diff})
ECONOMIA NOASTRĂ: ${economyUs} (${teamEcon?.avg_us ? "$" + teamEcon.avg_us : "N/A"})
ECONOMIA LOR: ${economyThem} (${teamEcon?.avg_them ? "$" + teamEcon.avg_them : "N/A"})
JUCĂTORI: ${playerNames}

TENDINȚE INAMICE OBSERVATE:
- Agresivi/Push-uri: ${tendencies.aggressive ? "DA - IMPORTANT: joacă pentru trade-uri, flash + trade" : "Nu"}
- Rotează rapid: ${tendencies.rotate_fast ? "DA - IMPORTANT: folosește fake util apoi hit tardiv" : "Nu"}
- Stack-uiesc des: ${tendencies.stack_frequent ? "DA - IMPORTANT: probe 2-1-2 apoi late pivot" : "Nu"}
- Re-peek des: ${tendencies.repeek ? "DA - IMPORTANT: hold angle după primul peek" : "Nu"}
- Mid focus: ${tendencies.mid_focus ? "DA - IMPORTANT: controlează mid devreme sau evită-l complet" : "Nu"}
- AWP agresiv: ${tendencies.awp_aggressive ? "DA - IMPORTANT: flash AWP-ul sau evită lane-ul" : "Nu"}
- Force/Eco des: ${tendencies.force_eco ? "DA - IMPORTANT: joacă anti-eco smart, nu te băga solo" : "Nu"}
- Folosesc fake-uri: ${tendencies.uses_fakes ? "DA - IMPORTANT: nu rota prea devreme pe baza util-ului" : "Nu"}
- Anti-eco slab: ${tendencies.antieco_weak ? "DA - IMPORTANT: pe eco-uri ai șanse de upset" : "Nu"}
- Late rotates: ${tendencies.late_rotate ? "DA - IMPORTANT: exec rapid funcționează, au puțini pe site" : "Nu"}
- Util heavy: ${tendencies.util_heavy ? "DA - IMPORTANT: așteaptă util-ul lor apoi intră" : "Nu"}

Generează un JSON cu această structură EXACTĂ (fără markdown, doar JSON):
{
  "strategy": {
    "voice": "Comanda vocală scurtă pentru echipă (în română)",
    "quick": {
      "buy": "Ce să cumpere echipa",
      "plan": "Planul în 1-2 propoziții",
      "fallback": "Ce facem dacă eșuează"
    },
    "layering": ["Strat 1 (0:20-1:25): ...", "Strat 2 (react): ...", "Strat 3 (0:55-0:25): ...", "Strat 4 (endgame): ..."],
    "roles": {"Entry": "P1", "Second": "P2", "Support": "P3", "Lurk": "P4", "Anchor": "P5"},
    "utility": ["P1: ...", "P2: ..."],
    "triggers": ["Dacă X atunci Y"],
    "win_conditions": ["Condiție 1", "Condiție 2"],
    "failure_branches": ["Dacă X: facem Y"],
    "notes": ["Notă importantă"]
  }
}

Răspunde DOAR cu JSON valid, fără explicații sau markdown.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    const text = response.text || "";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON in response");
    }

    const data = JSON.parse(jsonMatch[0]);
    const variant = data.strategy;

    const titleMap = {
      recommended: "Recommended Strategy",
      safe: "Safe Play",
      risk: "High Risk",
    };

    const typeMap = {
      recommended: "primary" as const,
      safe: "safe" as const,
      risk: "risk" as const,
    };

    const call: Call = {
      title: titleMap[strategyType],
      type: typeMap[strategyType],
      map,
      side,
      content: {
        voice: variant.voice || "",
        quick: {
          buy: variant.quick?.buy || "",
          plan: variant.quick?.plan || "",
          fallback: variant.quick?.fallback || "",
          drops: variant.quick?.drops,
        },
        layering: variant.layering || [],
        roles: variant.roles || {},
        utility: variant.utility || [],
        triggers: variant.triggers || [],
        win_conditions: variant.win_conditions || [],
        failure_branches: variant.failure_branches || [],
        notes: variant.notes,
      },
    };

    return {
      primary: strategyType === "recommended" ? call : null,
      safer: strategyType === "safe" ? call : null,
      risk: strategyType === "risk" ? call : null,
      selected: strategyType,
    };
  } catch (error) {
    console.error("Gemini IGL error:", error);
    throw error;
  }
}
