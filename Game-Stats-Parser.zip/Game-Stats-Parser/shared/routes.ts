import { z } from 'zod';
import { insertUserSchema, insertLobbySchema, insertStrategySchema, lobbies, strategies, users } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  // === Users / Faceit ===
  users: {
    create: {
      method: 'POST' as const,
      path: '/api/users',
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    getFaceit: {
      method: 'GET' as const,
      path: '/api/faceit/:nickname',
      responses: {
        200: z.object({
          faceit_id: z.string(),
          nickname: z.string(),
          avatar: z.string(),
          games: z.object({
            cs2: z.object({
              faceit_elo: z.number(),
              skill_level: z.number()
            })
          })
        }),
        404: errorSchemas.notFound,
      }
    }
  },

  // === Lobbies ===
  lobbies: {
    create: {
      method: 'POST' as const,
      path: '/api/lobbies',
      input: z.object({
        hostId: z.number(),
        map: z.string(),
      }),
      responses: {
        201: z.custom<typeof lobbies.$inferSelect>(),
      },
    },
    join: {
      method: 'POST' as const,
      path: '/api/lobbies/join',
      input: z.object({
        code: z.string(),
        userId: z.number(),
      }),
      responses: {
        200: z.custom<typeof lobbies.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/lobbies/:id',
      responses: {
        200: z.custom<typeof lobbies.$inferSelect & { members: (typeof users.$inferSelect & { isReady: boolean, role: string | null })[] }>(),
        404: errorSchemas.notFound,
      },
    },
    updateState: {
      method: 'PATCH' as const,
      path: '/api/lobbies/:id/state',
      input: z.object({
        round: z.number().optional(),
        scoreUs: z.number().optional(),
        scoreThem: z.number().optional(),
        aliveUs: z.number().optional(),
        aliveThem: z.number().optional(),
        timer: z.number().optional(),
        economyUs: z.enum(["eco", "force", "full"]).optional(),
        economyThem: z.enum(["eco", "force", "full"]).optional(),
      }),
      responses: {
        200: z.custom<typeof lobbies.$inferSelect>(),
      },
    }
  },

  // === AI / Strategies ===
  ai: {
    generate: {
      method: 'POST' as const,
      path: '/api/ai/generate',
      input: z.object({
        lobbyId: z.number().optional(),
        map: z.string(),
        side: z.enum(["CT", "T"]),
        scoreUs: z.number().optional(),
        scoreThem: z.number().optional(),
        economyUs: z.enum(["eco", "force", "full"]).optional(),
        economyThem: z.enum(["eco", "force", "full"]).optional(),
        strategyType: z.enum(["recommended", "safe", "risk"]).optional(),
        history: z.array(z.string()).optional(),
      }),
      responses: {
        200: z.object({
          primary: z.custom<typeof strategies.$inferSelect>().nullable(),
          safer: z.custom<typeof strategies.$inferSelect>().nullable(),
          risk: z.custom<typeof strategies.$inferSelect>().nullable(),
          selected: z.enum(["recommended", "safe", "risk"]).optional(),
          source: z.string().optional(),
        }),
      },
    },
  },
  
  strategies: {
    list: {
        method: 'GET' as const,
        path: '/api/strategies',
        responses: {
            200: z.array(z.custom<typeof strategies.$inferSelect>()),
        }
    },
    create: {
        method: 'POST' as const,
        path: '/api/strategies',
        input: insertStrategySchema,
        responses: {
            201: z.custom<typeof strategies.$inferSelect>(),
        }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
