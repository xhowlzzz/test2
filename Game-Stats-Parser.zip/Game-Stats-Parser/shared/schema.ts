import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// === Users / Players ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  faceitId: text("faceit_id"),
  faceitElo: integer("faceit_elo"),
  faceitAvatar: text("faceit_avatar"),
  preferredRole: text("preferred_role"), // Entry, Support, AWP, Lurk, IGL
  createdAt: timestamp("created_at").defaultNow(),
});

// === Lobbies ===
export const lobbies = pgTable("lobbies", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // Room Code (e.g., X7K9A2)
  hostId: integer("host_id").references(() => users.id),
  map: text("map"), // Mirage, Inferno, etc.
  side: text("side").default("CT"), // CT or T
  scoreUs: integer("score_us").default(0),
  scoreThem: integer("score_them").default(0),
  state: jsonb("state").$type<{
    round: number;
    economyUs: "eco" | "force" | "full";
    economyThem: "eco" | "force" | "full";
    aliveUs: number;
    aliveThem: number;
    timer: number;
  }>().default({
    round: 1,
    economyUs: "eco",
    economyThem: "eco",
    aliveUs: 5,
    aliveThem: 5,
    timer: 115
  }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// === Lobby Members ===
export const lobbyMembers = pgTable("lobby_members", {
  id: serial("id").primaryKey(),
  lobbyId: integer("lobby_id").notNull().references(() => lobbies.id),
  userId: integer("user_id").notNull().references(() => users.id),
  role: text("role"), // Assigned role for match
  isReady: boolean("is_ready").default(false),
  joinedAt: timestamp("joined_at").defaultNow(),
});

// === Strategies (Playbook) ===
export const strategies = pgTable("strategies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  map: text("map").notNull(),
  side: text("side").notNull(), // CT or T
  type: text("type").notNull(), // Default, Exec, Split, Fake, etc.
  content: jsonb("content").notNull().$type<{
    description: string;
    steps: string[];
    utility: string[];
    roles: Record<string, string>;
  }>(),
  isPublic: boolean("is_public").default(false),
  creatorId: integer("creator_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// === Relations ===
export const usersRelations = relations(users, ({ many }) => ({
  lobbies: many(lobbyMembers),
}));

export const lobbiesRelations = relations(lobbies, ({ one, many }) => ({
  host: one(users, {
    fields: [lobbies.hostId],
    references: [users.id],
  }),
  members: many(lobbyMembers),
}));

export const lobbyMembersRelations = relations(lobbyMembers, ({ one }) => ({
  lobby: one(lobbies, {
    fields: [lobbyMembers.lobbyId],
    references: [lobbies.id],
  }),
  user: one(users, {
    fields: [lobbyMembers.userId],
    references: [users.id],
  }),
}));

// === Zod Schemas ===
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertLobbySchema = createInsertSchema(lobbies).omit({ id: true, createdAt: true, state: true });
export const insertStrategySchema = createInsertSchema(strategies).omit({ id: true, createdAt: true });

// === Types ===
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Lobby = typeof lobbies.$inferSelect;
export type InsertLobby = z.infer<typeof insertLobbySchema>;
export type Strategy = typeof strategies.$inferSelect;
export type InsertStrategy = z.infer<typeof insertStrategySchema>;
export type LobbyMember = typeof lobbyMembers.$inferSelect;

export * from "./models/chat";
