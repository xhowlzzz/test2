## Packages
framer-motion | Complex animations for the esports aesthetic
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
WebSocket connects to /ws for real-time lobby updates
Faceit API is mocked via internal backend routes
