import {
  require_react
} from "./chunk-WTNFPL7F.js";
export default require_react();
