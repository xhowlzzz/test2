import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateLobby, useJoinLobby } from "@/hooks/use-lobbies";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Plus, Users, Sparkles, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";

export default function LobbySelection() {
  const [, setLocation] = useLocation();
  const createLobby = useCreateLobby();
  const joinLobby = useJoinLobby();
  const [joinCode, setJoinCode] = useState("");
  
  const userId = Number(localStorage.getItem("userId"));
  const username = localStorage.getItem("username") || "Jucător";

  const handleCreate = async () => {
    try {
      const lobby = await createLobby.mutateAsync({
        hostId: userId,
        map: "Mirage",
      });
      setLocation(`/lobby/${lobby.id}`);
    } catch (err) {
      console.error(err);
    }
  };

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinCode) return;
    try {
      const lobby = await joinLobby.mutateAsync({
        code: joinCode.toUpperCase(),
        userId,
      });
      setLocation(`/lobby/${lobby.id}`);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 -left-32 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 -right-32 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-md space-y-6"
      >
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2 text-emerald-400 mb-4">
            <Sparkles className="w-5 h-5" />
            <span className="text-sm font-medium">Bine ai venit, {username}!</span>
          </div>
          <h2 className="text-4xl font-display font-bold text-white">
            Centru de Comandă
          </h2>
          <p className="text-slate-400">
            Creează sau alătură-te unui lobby
          </p>
        </div>

        <Tabs defaultValue="create" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-800/50 border border-slate-700/50 p-1.5 rounded-xl">
            <TabsTrigger 
              value="create" 
              className="font-medium rounded-lg data-[state=active]:bg-emerald-500 data-[state=active]:text-white data-[state=active]:shadow-lg"
            >
              Creează Lobby
            </TabsTrigger>
            <TabsTrigger 
              value="join" 
              className="font-medium rounded-lg data-[state=active]:bg-blue-500 data-[state=active]:text-white data-[state=active]:shadow-lg"
            >
              Alătură-te
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="create">
            <Card className="bg-slate-900/80 backdrop-blur-xl border-slate-700/50 p-8 mt-4 shadow-2xl">
              <div className="text-center space-y-6">
                <div className="w-20 h-20 bg-gradient-to-br from-emerald-500/20 to-emerald-600/20 rounded-2xl flex items-center justify-center mx-auto border border-emerald-500/30">
                  <Plus className="w-10 h-10 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Lobby Nou</h3>
                  <p className="text-slate-400 text-sm">
                    Pornește o nouă sesiune tactică și invită-ți echipa
                  </p>
                </div>
                <Button 
                  onClick={handleCreate} 
                  disabled={createLobby.isPending}
                  className="w-full h-14 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-bold text-lg shadow-lg shadow-emerald-500/25"
                >
                  {createLobby.isPending ? (
                    <Loader2 className="animate-spin" />
                  ) : (
                    "CREEAZĂ LOBBY"
                  )}
                </Button>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="join">
            <Card className="bg-slate-900/80 backdrop-blur-xl border-slate-700/50 p-8 mt-4 shadow-2xl">
              <form onSubmit={handleJoin} className="space-y-6 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-2xl flex items-center justify-center mx-auto border border-blue-500/30">
                  <Users className="w-10 h-10 text-blue-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Intră în Lobby</h3>
                  <p className="text-slate-400 text-sm">
                    Introdu codul primit de la căpitan
                  </p>
                </div>
                <div className="space-y-2">
                  <Input 
                    placeholder="INTRODU CODUL (ex: X7K9)" 
                    className="text-center font-mono uppercase text-xl bg-slate-800/80 border-slate-600/50 h-14 tracking-[0.3em] focus:ring-blue-500/50"
                    maxLength={6}
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value)}
                  />
                </div>
                <Button 
                  type="submit" 
                  disabled={joinLobby.isPending || !joinCode}
                  className="w-full h-14 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold text-lg shadow-lg shadow-blue-500/25"
                >
                  {joinLobby.isPending ? (
                    <Loader2 className="animate-spin" />
                  ) : (
                    "CONECTEAZĂ-TE"
                  )}
                </Button>
              </form>
            </Card>
          </TabsContent>
        </Tabs>

        <button
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 text-slate-500 hover:text-slate-300 transition-colors mx-auto text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          Înapoi la pagina principală
        </button>
      </motion.div>
    </div>
  );
}
