import { useStrategies } from "@/hooks/use-strategies";
import { StratCard } from "@/components/StratCard";
import { Loader2 } from "lucide-react";

export default function Playbook() {
  const { data: strategies, isLoading } = useStrategies();

  return (
    <div className="min-h-screen p-8 max-w-7xl mx-auto">
       <div className="mb-8">
         <h1 className="text-4xl font-display font-black uppercase tracking-tighter mb-2">Tactical Playbook</h1>
         <p className="text-muted-foreground font-mono">Archive of successful strategies.</p>
       </div>

       {isLoading ? (
         <div className="flex justify-center py-20"><Loader2 className="animate-spin h-10 w-10 text-primary" /></div>
       ) : (
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           {strategies?.map((strat) => (
             <StratCard 
              key={strat.id} 
              strategy={strat} 
              variant="primary" // Default to primary style for list view
            />
           ))}
         </div>
       )}
    </div>
  );
}
