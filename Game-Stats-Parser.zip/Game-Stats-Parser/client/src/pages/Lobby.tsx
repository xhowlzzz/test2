import { useEffect, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useLobby } from "@/hooks/use-lobbies";
import { useWebSocket } from "@/hooks/use-websocket";
import { PlayerCard } from "@/components/PlayerCard";
import { MapCard } from "@/components/MapCard";
import { Button } from "@/components/ui/button";
import { Loader2, Copy, Play, Users, MapPin, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

const MAPS = [
  { name: "Mirage", img: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&fit=crop" },
  { name: "Dust2", img: "https://images.unsplash.com/photo-1519669556878-63bd08be63f9?w=800&fit=crop" },
  { name: "Inferno", img: "https://images.unsplash.com/photo-1563089145-599997674d42?w=800&fit=crop" },
  { name: "Nuke", img: "https://images.unsplash.com/photo-1577789182315-71cb9452b453?w=800&fit=crop" },
  { name: "Overpass", img: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&fit=crop" },
  { name: "Ancient", img: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=800&fit=crop" },
  { name: "Anubis", img: "https://images.unsplash.com/photo-1599557797072-a0b686303254?w=800&fit=crop" },
  { name: "Train", img: "https://images.unsplash.com/photo-1474487548417-781cb71495f3?w=800&fit=crop" },
];

export default function Lobby() {
  const [, params] = useRoute("/lobby/:id");
  const lobbyId = Number(params?.id);
  const { data: lobby, isLoading } = useLobby(lobbyId);
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedMap, setSelectedMap] = useState("Mirage");
  
  const { sendMessage, lastMessage } = useWebSocket(lobbyId);

  const userId = Number(localStorage.getItem("userId"));
  const isHost = lobby?.hostId === userId;

  useEffect(() => {
    if (lastMessage?.type === "MATCH_START") {
      setLocation(`/match/${lobbyId}`);
    }
  }, [lastMessage, lobbyId, setLocation]);

  useEffect(() => {
    if (lobby?.map) setSelectedMap(lobby.map);
  }, [lobby?.map]);

  const copyCode = () => {
    navigator.clipboard.writeText(lobby?.code || "");
    toast({ 
      title: "Cod copiat!", 
      description: "Trimite acest cod coechipierilor tăi." 
    });
  };

  const startMatch = () => {
    sendMessage({ type: "START_MATCH" });
    setLocation(`/match/${lobbyId}`);
  };

  if (isLoading || !lobby) {
    return (
      <div className="h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-emerald-400 mx-auto mb-4" />
          <p className="text-slate-400">Se încarcă lobby-ul...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 max-w-7xl mx-auto bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-slate-700/50 p-6"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <p className="text-slate-400 text-sm mb-2">Lobby Echipă</p>
              <div className="flex items-center gap-4">
                <h1 className="text-5xl md:text-6xl font-display font-black tracking-tight text-white">
                  {lobby.code}
                </h1>
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={copyCode} 
                  className="h-12 w-12 border-slate-600/50 hover:bg-emerald-500/10 hover:border-emerald-500/50 hover:text-emerald-400"
                >
                  <Copy size={18} />
                </Button>
              </div>
              <p className="text-slate-500 text-sm mt-2">
                Trimite codul echipei tale pentru a se alătura
              </p>
            </div>

            <div className="flex gap-4">
              <Button 
                size="lg"
                className="h-14 px-8 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-bold text-lg shadow-lg shadow-emerald-500/25 transition-all hover:scale-[1.02]"
                onClick={startMatch}
                disabled={!isHost}
              >
                {isHost ? (
                  <>
                    <Play className="mr-2 fill-current" />
                    Începe Meciul
                  </>
                ) : (
                  <>
                    <Loader2 className="mr-2 animate-spin" />
                    Așteptăm Căpitanul...
                  </>
                )}
              </Button>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 space-y-4"
          >
            <div className="flex items-center gap-3 mb-4">
              <Users className="w-5 h-5 text-emerald-400" />
              <h2 className="text-xl font-bold text-white">
                Echipa ({lobby.members.length}/5)
              </h2>
            </div>
            
            <div className="grid gap-3">
              {lobby.members.map((member, index) => (
                <motion.div 
                  key={member.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 * index }}
                >
                  <PlayerCard 
                    member={member} 
                    isHost={lobby.hostId === member.id} 
                  />
                </motion.div>
              ))}
              
              {Array.from({ length: Math.max(0, 5 - lobby.members.length) }).map((_, i) => (
                <div 
                  key={`empty-${i}`} 
                  className="h-20 border-2 border-dashed border-slate-700/50 rounded-xl flex items-center justify-center text-slate-600 font-medium"
                >
                  <Users className="w-5 h-5 mr-2 opacity-50" />
                  Slot Liber
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-3 mb-4">
              <MapPin className="w-5 h-5 text-blue-400" />
              <h2 className="text-xl font-bold text-white">Selectează Harta</h2>
            </div>
            
            <div className="grid grid-cols-1 gap-3 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
              {MAPS.map((map) => (
                <MapCard 
                  key={map.name}
                  name={map.name}
                  image={map.img}
                  selected={selectedMap === map.name}
                  onClick={() => isHost && setSelectedMap(map.name)}
                />
              ))}
            </div>
            
            {!isHost && (
              <p className="text-slate-500 text-xs text-center">
                Doar căpitanul poate schimba harta
              </p>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
