import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateUser, useFaceitStats } from "@/hooks/use-users";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { GlitchText } from "@/components/GlitchText";
import { Loader2, ArrowRight, Crosshair, Zap, Users } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  const [nickname, setNickname] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [, setLocation] = useLocation();
  const createUser = useCreateUser();
  const { data: faceitData, isLoading: isCheckingFaceit } =
    useFaceitStats(nickname);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nickname) return;

    setIsSubmitting(true);
    try {
      const user = await createUser.mutateAsync({
        username: nickname,
        faceitId: faceitData?.faceit_id,
        faceitElo: faceitData?.games?.cs2?.faceit_elo,
        faceitAvatar: faceitData?.avatar,
      });

      localStorage.setItem("userId", String(user.id));
      localStorage.setItem("username", user.username);
      setLocation("/lobbies");
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950/30">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -left-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-emerald-500/5 to-transparent rounded-full" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 w-full max-w-lg"
      >
        <div className="text-center mb-10">
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h1 className="text-7xl md:text-8xl font-display font-black tracking-tighter mb-3">
              <GlitchText text="STRAT" />
              <span className="text-emerald-400">OS</span>
            </h1>
          </motion.div>
          <p className="text-slate-400 font-medium text-lg md:text-xl">
            Asistentul tău IGL pentru Counter-Strike 2
          </p>
          <p className="text-slate-500 text-sm mt-2">
            Strategii generate de AI pentru a domina competiția
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="grid grid-cols-3 gap-3 mb-8"
        >
          <div className="bg-slate-800/40 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50 text-center">
            <Crosshair className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
            <p className="text-xs text-slate-400">Tactici Precise</p>
          </div>
          <div className="bg-slate-800/40 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50 text-center">
            <Zap className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <p className="text-xs text-slate-400">Call-uri Rapide</p>
          </div>
          <div className="bg-slate-800/40 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50 text-center">
            <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <p className="text-xs text-slate-400">Sync Echipă</p>
          </div>
        </motion.div>

        <Card className="bg-slate-900/80 backdrop-blur-xl border-slate-700/50 p-6 shadow-2xl shadow-emerald-500/5">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-xs font-medium uppercase text-slate-400 tracking-wider">
                Numele tău de jucător
              </label>
              <div className="relative">
                <Input
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  placeholder="ex: s1mple, NiKo, ZywOo"
                  className="bg-slate-800/80 border-slate-600/50 h-14 text-lg font-medium tracking-wide focus:ring-emerald-500/50 focus:border-emerald-500/50 placeholder:text-slate-500"
                  autoFocus
                />
                {isCheckingFaceit && (
                  <div className="absolute right-4 top-4">
                    <Loader2 className="animate-spin text-emerald-400 h-5 w-5" />
                  </div>
                )}
              </div>
              {faceitData && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="flex items-center gap-3 text-sm bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-lg"
                >
                  {faceitData.avatar && (
                    <img src={faceitData.avatar} alt="" className="w-8 h-8 rounded-full" />
                  )}
                  <div>
                    <p className="text-emerald-300 font-medium">Profil FACEIT găsit</p>
                    <p className="text-emerald-400/70 text-xs">
                      ELO: {faceitData.games?.cs2?.faceit_elo || "N/A"}
                    </p>
                  </div>
                </motion.div>
              )}
            </div>

            <Button
              type="submit"
              className="w-full h-14 text-lg font-bold bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white transition-all hover:scale-[1.02] shadow-lg shadow-emerald-500/25"
              disabled={isSubmitting || !nickname}
            >
              {isSubmitting ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <>
                  INTRĂ ÎN SISTEM <ArrowRight className="ml-2" />
                </>
              )}
            </Button>
          </form>
        </Card>

        <p className="text-center text-slate-500 text-xs mt-6">
          Versiune 2.0 • Powered by Groq AI
        </p>
      </motion.div>
    </div>
  );
}
