import { useEffect, useMemo, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useLobby, useCloseLobby } from "@/hooks/use-lobbies";
import { useWebSocket } from "@/hooks/use-websocket";
import { ChatBox } from "@/components/ChatBox";
import { StratCard } from "@/components/StratCard";
import CTPositions from "@/components/CTPositions";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { LogOut, Zap, Shield, Flame } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function MatchDashboard() {
  const [, params] = useRoute("/match/:id");
  const [, setLocation] = useLocation();
  const lobbyId = Number(params?.id);
  const { data: lobby, isLoading } = useLobby(lobbyId);
  const closeLobby = useCloseLobby();

  const ws = useWebSocket(lobbyId);
  const lastMessage = ws?.lastMessage ?? null;

  const [side, setSide] = useState<"CT" | "T">("CT");
  const [syncedStrats, setSyncedStrats] = useState<any>(null);
  const [wsMessages, setWsMessages] = useState<any[]>([]);
  
  const [roundHistory, setRoundHistory] = useState<Array<{ won: boolean; planted?: boolean }>>(() => {
    const saved = localStorage.getItem(`lobby_${lobbyId}_roundHistory`);
    return saved ? JSON.parse(saved) : [];
  });
  const [lossStreak, setLossStreak] = useState(() => {
    const saved = localStorage.getItem(`lobby_${lobbyId}_lossStreak`);
    return saved ? Number(saved) : 0;
  });
  const [playerPositions, setPlayerPositions] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem(`lobby_${lobbyId}_positions`);
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem(`lobby_${lobbyId}_roundHistory`, JSON.stringify(roundHistory));
  }, [roundHistory, lobbyId]);

  useEffect(() => {
    localStorage.setItem(`lobby_${lobbyId}_lossStreak`, String(lossStreak));
  }, [lossStreak, lobbyId]);

  useEffect(() => {
    if (Object.keys(playerPositions).length > 0) {
      localStorage.setItem(`lobby_${lobbyId}_positions`, JSON.stringify(playerPositions));
    }
  }, [playerPositions, lobbyId]);

  const handleCloseSession = async () => {
    if (confirm("Ești sigur că vrei să închizi sesiunea? Vei fi redirecționat la lobby-uri.")) {
      localStorage.removeItem(`lobby_${lobbyId}_roundHistory`);
      localStorage.removeItem(`lobby_${lobbyId}_lossStreak`);
      localStorage.removeItem(`lobby_${lobbyId}_positions`);
      localStorage.removeItem(`lobby_${lobbyId}_chat`);
      try {
        await closeLobby.mutateAsync(lobbyId);
      } catch (e) {
        console.error("Error closing lobby:", e);
      }
      setLocation("/lobbies");
    }
  };

  const currentUser = useMemo(() => {
    const storedUser = localStorage.getItem("cs2_current_user");
    if (storedUser) {
      try {
        return JSON.parse(storedUser);
      } catch {
        return null;
      }
    }
    const members = (lobby as any)?.members;
    if (members?.length > 0) {
      const me = members.find((m: any) => m.id === (lobby as any)?.me?.id);
      return me ? {
        id: me.id,
        username: me.username,
        avatar: me.faceitAvatar,
      } : {
        id: members[0].id,
        username: members[0].username,
        avatar: members[0].faceitAvatar,
      };
    }
    return null;
  }, [lobby]);

  useEffect(() => {
    if (lobby?.side) setSide(lobby.side as "CT" | "T");
  }, [lobby?.side]);

  useEffect(() => {
    if (!lastMessage) return;
    if (lastMessage.type === "CHAT_MESSAGE") {
      setWsMessages((prev) => [...prev, lastMessage]);
    }
    if (lastMessage.type === "STRATEGY_UPDATE") {
      setSyncedStrats((lastMessage as any).strategy);
    }
    if (lastMessage.type === "lobby_update") {
      if ((lastMessage as any).data?.type === "STRATEGY_UPDATE") {
        setSyncedStrats((lastMessage as any).data.strategy);
      }
      if ((lastMessage as any).data?.type === "CHAT_MESSAGE") {
        setWsMessages((prev) => [...prev, (lastMessage as any).data]);
      }
    }
  }, [lastMessage]);

  const players = useMemo(() => {
    const members = (lobby as any)?.members || [];
    return members.map((m: any) => ({
      username: m.username,
      role: m.role,
    }));
  }, [lobby]);

  const [currentMap, setCurrentMap] = useState((lobby as any)?.map || "Mirage");
  
  useEffect(() => {
    if ((lobby as any)?.map) setCurrentMap((lobby as any).map);
  }, [(lobby as any)?.map]);

  if (isLoading || !lobby) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-slate-400 text-lg"
        >
          Se încarcă...
        </motion.div>
      </div>
    );
  }

  const processedStrats = syncedStrats ? {
    primary: (syncedStrats as any).primary ? {
      ...(syncedStrats as any).primary,
      content: {
        ...(syncedStrats as any).primary.content,
        steps: (syncedStrats as any).primary.content?.steps || (syncedStrats as any).primary.content?.layering || []
      }
    } : null,
    safer: (syncedStrats as any).safer ? {
      ...(syncedStrats as any).safer,
      content: {
        ...(syncedStrats as any).safer.content,
        steps: (syncedStrats as any).safer.content?.steps || (syncedStrats as any).safer.content?.layering || []
      }
    } : null,
    risk: (syncedStrats as any).risk ? {
      ...(syncedStrats as any).risk,
      content: {
        ...(syncedStrats as any).risk.content,
        steps: (syncedStrats as any).risk.content?.steps || (syncedStrats as any).risk.content?.layering || []
      }
    } : null,
    selected: (syncedStrats as any).selected,
  } : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 overflow-hidden">
      <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center opacity-5" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
      
      <div className="relative p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-gradient-to-r from-slate-800/60 to-slate-900/60 rounded-2xl border border-slate-700/50 p-4 backdrop-blur-xl shadow-2xl"
        >
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-3 h-3 bg-emerald-500 rounded-full shadow-lg shadow-emerald-500/50"
                />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-400 via-white to-blue-400 bg-clip-text text-transparent">
                  StratOS
                </h1>
              </div>
              <Badge className="bg-slate-700/50 text-slate-300 border-slate-600 backdrop-blur-sm">
                {lobby.code}
              </Badge>
              <select
                value={currentMap}
                onChange={(e) => setCurrentMap(e.target.value)}
                className="bg-slate-800/80 border border-slate-600/50 rounded-xl px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 cursor-pointer backdrop-blur-sm transition-all hover:border-emerald-500/50"
              >
                <option value="Mirage">Mirage</option>
                <option value="Dust2">Dust 2</option>
                <option value="Inferno">Inferno</option>
                <option value="Ancient">Ancient</option>
                <option value="Anubis">Anubis</option>
                <option value="Nuke">Nuke</option>
                <option value="Vertigo">Vertigo</option>
              </select>
              <div className="flex bg-slate-800/80 p-1 rounded-xl border border-slate-600/50 backdrop-blur-sm">
                <button
                  className={cn(
                    "px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-300",
                    side === "CT" 
                      ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg shadow-blue-600/30" 
                      : "text-slate-400 hover:text-white hover:bg-slate-700/50"
                  )}
                  onClick={() => setSide("CT")}
                >
                  CT
                </button>
                <button
                  className={cn(
                    "px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-300",
                    side === "T" 
                      ? "bg-gradient-to-r from-orange-600 to-orange-700 text-white shadow-lg shadow-orange-600/30" 
                      : "text-slate-400 hover:text-white hover:bg-slate-700/50"
                  )}
                  onClick={() => setSide("T")}
                >
                  T
                </button>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-800/60 rounded-xl border border-slate-700/50">
                <span className="text-xs text-slate-400">Loss Streak:</span>
                <span className={cn(
                  "font-bold",
                  lossStreak >= 3 ? "text-red-400" : lossStreak >= 1 ? "text-orange-400" : "text-emerald-400"
                )}>
                  {lossStreak}
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleCloseSession}
                className="bg-red-500/10 border-red-500/30 text-red-400 hover:bg-red-500/20 hover:text-red-300 hover:border-red-500/50 transition-all"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Închide
              </Button>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="lg:col-span-1 space-y-4"
          >
            <CTPositions
              map={currentMap}
              side={side}
              members={(lobby as any)?.members || []}
              positions={playerPositions}
              onPositionsChange={setPlayerPositions}
            />

            <ChatBox
              lobbyId={lobbyId}
              map={currentMap}
              side={side}
              tendencies={{}}
              currentUser={currentUser}
              wsMessages={wsMessages}
              players={players}
              strategyType="recommended"
              onStrategyGenerated={(strat) => setSyncedStrats(strat)}
              playerPositions={playerPositions}
              economy={{
                lossStreak,
                roundHistory,
                onRoundResult: (won, planted) => {
                  setRoundHistory((prev) => [...prev, { won, planted }]);
                  if (won) {
                    setLossStreak(0);
                  } else {
                    setLossStreak((prev) => Math.min(5, prev + 1));
                  }
                },
              }}
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:col-span-2"
          >
            <AnimatePresence mode="wait">
              {processedStrats ? (
                <motion.div
                  key="strategies"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <motion.div
                      animate={{ rotate: [0, 360] }}
                      transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                      className="w-8 h-8 rounded-full bg-gradient-to-r from-emerald-500 to-blue-500 flex items-center justify-center"
                    >
                      <Zap className="w-4 h-4 text-white" />
                    </motion.div>
                    <h2 className="text-xl font-bold text-white">Strategii Generate</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {processedStrats.primary && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="relative group"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-emerald-500/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all opacity-50" />
                        <div className="relative">
                          <div className="flex items-center gap-2 mb-2">
                            <Zap className="w-4 h-4 text-blue-400" />
                            <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Recomandat</span>
                          </div>
                          <StratCard strategy={processedStrats.primary} variant="primary" />
                        </div>
                      </motion.div>
                    )}
                    {processedStrats.safer && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="relative group"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all opacity-50" />
                        <div className="relative">
                          <div className="flex items-center gap-2 mb-2">
                            <Shield className="w-4 h-4 text-green-400" />
                            <span className="text-xs font-semibold text-green-400 uppercase tracking-wider">Sigur</span>
                          </div>
                          <StratCard strategy={processedStrats.safer} variant="safe" />
                        </div>
                      </motion.div>
                    )}
                    {processedStrats.risk && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                        className="relative group"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all opacity-50" />
                        <div className="relative">
                          <div className="flex items-center gap-2 mb-2">
                            <Flame className="w-4 h-4 text-orange-400" />
                            <span className="text-xs font-semibold text-orange-400 uppercase tracking-wider">Risc Mare</span>
                          </div>
                          <StratCard strategy={processedStrats.risk} variant="risk" />
                        </div>
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="placeholder"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center justify-center h-96 rounded-2xl border border-dashed border-slate-700/50 bg-slate-900/30 backdrop-blur-sm"
                >
                  <motion.div
                    animate={{ 
                      scale: [1, 1.1, 1],
                      opacity: [0.5, 1, 0.5]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-16 h-16 rounded-full bg-gradient-to-r from-emerald-500/20 to-blue-500/20 flex items-center justify-center mb-4"
                  >
                    <Zap className="w-8 h-8 text-emerald-400" />
                  </motion.div>
                  <h3 className="text-lg font-semibold text-slate-300 mb-2">Așteaptă Strategii</h3>
                  <p className="text-sm text-slate-500 text-center max-w-md">
                    Scrie situația în chat (ex: "runda de pistoale", "suntem eco, ei full buy") 
                    și primești 3 strategii: Recomandat, Sigur și Risc
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
