import { motion } from "framer-motion";
import clsx from "clsx";

interface MapCardProps {
  name: string;
  selected: boolean;
  onClick: () => void;
  image?: string;
}

export function MapCard({ name, selected, onClick, image }: MapCardProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={clsx(
        "relative h-32 w-full overflow-hidden rounded-lg border-2 transition-all duration-200 group",
        selected 
          ? "border-primary shadow-[0_0_15px_rgba(0,255,157,0.3)]" 
          : "border-white/10 hover:border-white/30"
      )}
    >
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
        style={{ backgroundImage: `url(${image || '/maps/default.jpg'})` }}
      />
      <div className={clsx(
        "absolute inset-0 bg-black/60 transition-colors",
        selected ? "bg-primary/20" : "group-hover:bg-black/40"
      )} />
      
      <div className="absolute bottom-2 left-3">
        <h3 className={clsx(
          "font-display text-lg font-bold uppercase tracking-wider",
          selected ? "text-white text-glow" : "text-gray-300"
        )}>
          {name}
        </h3>
      </div>
      
      {selected && (
        <div className="absolute top-2 right-2 h-3 w-3 rounded-full bg-primary shadow-[0_0_10px_rgba(0,255,157,1)] animate-pulse" />
      )}
    </motion.button>
  );
}
