import { motion } from "framer-motion";

interface GlitchTextProps {
  text: string;
  className?: string;
  as?: React.ElementType;
}

export function GlitchText({ text, className = "", as: Component = "span" }: GlitchTextProps) {
  return (
    <Component className={`relative inline-block ${className}`}>
      <span className="relative z-10">{text}</span>
      <span className="absolute top-0 left-0 -z-10 translate-x-[2px] text-red-500 opacity-70 animate-pulse">
        {text}
      </span>
      <span className="absolute top-0 left-0 -z-10 -translate-x-[2px] text-blue-500 opacity-70 animate-pulse delay-75">
        {text}
      </span>
    </Component>
  );
}
