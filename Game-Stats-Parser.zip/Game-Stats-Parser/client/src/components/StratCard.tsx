import { Strategy } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Shield, Sword, AlertTriangle, Volume2, VolumeX } from "lucide-react";
import { useTTS } from "@/hooks/useTTS";

interface StratCardProps {
  strategy: {
    title: string;
    type: string;
    content: {
      description?: string;
      voice?: string;
      quick?: {
        buy: string;
        plan: string;
        fallback: string;
      };
      layering?: string[];
      steps?: string[];
      utility: string[];
      roles: Record<string, string>;
    };
  };
  variant: "primary" | "safe" | "risk";
}

const variants = {
  primary: {
    color: "border-primary/50 shadow-[0_0_20px_rgba(0,255,157,0.1)]",
    icon: Sword,
    label: "Recomandat",
    badge: "bg-primary/20 text-primary border-primary/20"
  },
  safe: {
    color: "border-blue-500/50 shadow-[0_0_20px_rgba(59,130,246,0.1)]",
    icon: Shield,
    label: "Sigur",
    badge: "bg-blue-500/20 text-blue-400 border-blue-500/20"
  },
  risk: {
    color: "border-orange-500/50 shadow-[0_0_20px_rgba(249,115,22,0.1)]",
    icon: AlertTriangle,
    label: "Risc Mare",
    badge: "bg-orange-500/20 text-orange-400 border-orange-500/20"
  }
};

export function StratCard({ strategy, variant }: StratCardProps) {
  const style = variants[variant];
  const { toggle, isSpeaking, isSupported } = useTTS();
  
  if (!style) return null;
  const Icon = style.icon;

  const getFullText = () => {
    const parts: string[] = [];
    
    if (strategy.content.voice) {
      parts.push(strategy.content.voice);
    } else if (strategy.content.description) {
      parts.push(strategy.content.description);
    }

    if (strategy.content.quick?.buy) {
      parts.push(`Buy: ${strategy.content.quick.buy}`);
    }

    const steps = strategy.content.steps || strategy.content.layering || [];
    if (steps.length > 0) {
      parts.push("Execution:");
      steps.forEach((step, i) => {
        parts.push(`${i + 1}. ${step}`);
      });
    }

    return parts.join(". ");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="h-full"
    >
      <Card className={`h-full bg-card/60 backdrop-blur-md border-2 ${style.color} overflow-hidden`}>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start mb-2">
            <Badge variant="outline" className={style.badge}>
              <Icon size={12} className="mr-1" /> {style.label}
            </Badge>
            <div className="flex items-center gap-2">
              {isSupported && (
                <Button
                  variant="ghost"
                  size="icon"
                  className={`h-7 w-7 ${isSpeaking ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-400 hover:text-white'}`}
                  onClick={() => toggle(getFullText())}
                  title={isSpeaking ? "Oprește" : "Citește cu voce"}
                >
                  {isSpeaking ? <VolumeX size={16} /> : <Volume2 size={16} />}
                </Button>
              )}
              <Badge variant="secondary" className="bg-white/5">{strategy.type}</Badge>
            </div>
          </div>
          <CardTitle className="font-display text-2xl uppercase tracking-wide">{strategy.title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground text-sm leading-relaxed border-l-2 border-white/10 pl-3">
            {strategy.content.description || strategy.content.voice}
          </p>
          
          <div className="space-y-2">
            <h4 className="text-xs font-mono uppercase text-muted-foreground tracking-widest mb-2">Execuție</h4>
            <ul className="space-y-2">
              {(strategy.content.steps || strategy.content.layering || []).map((step: string, i: number) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className="flex-shrink-0 w-5 h-5 rounded bg-white/5 flex items-center justify-center text-xs font-mono text-muted-foreground">
                    {i + 1}
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-4">
             {(strategy.content.utility || []).slice(0, 4).map((util: string, i: number) => (
               <div key={i} className="text-xs px-2 py-1 rounded bg-white/5 text-muted-foreground border border-white/5 text-center">
                 {util}
               </div>
             ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
