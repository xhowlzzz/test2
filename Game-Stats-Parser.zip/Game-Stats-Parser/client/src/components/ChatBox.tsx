import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type Sender = {
  id: number;
  username: string;
  avatar?: string;
};

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  sender?: Sender;
};

type Player = { username: string; role?: string };

type EconomyState = {
  lossStreak: number;
  roundHistory: Array<{ won: boolean; planted?: boolean }>;
  onRoundResult?: (won: boolean, planted?: boolean) => void;
};

export function ChatBox({
  lobbyId,
  map,
  side,
  tendencies,
  currentUser,
  onStrategyGenerated,
  wsMessages,
  players,
  strategyType,
  economy,
  playerPositions,
}: {
  lobbyId: number;
  map: string;
  side: "CT" | "T";
  tendencies: Record<string, boolean>;
  currentUser?: Sender;
  onStrategyGenerated?: (strat: any) => void;
  wsMessages?: any[];
  players?: Player[];
  strategyType?: "recommended" | "safe" | "risk";
  economy?: EconomyState;
  playerPositions?: Record<string, string>;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const seenContents = useRef<Set<string>>(new Set());

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (!wsMessages || wsMessages.length === 0) return;
    
    const lastMsg = wsMessages[wsMessages.length - 1];
    
    // Handle direct CHAT_MESSAGE type (from fixed broadcast)
    if (lastMsg.type === "CHAT_MESSAGE" && lastMsg.message) {
      const msg = lastMsg.message;
      
      // Skip AI/assistant messages - they go to StratCard, not chat
      if (msg.role === "assistant") return;
      
      const msgKey = msg.id || `${msg.role}-${msg.timestamp}-${msg.content?.slice(0, 30)}`;
      
      // Skip if already seen
      if (seenContents.current.has(msgKey)) return;
      
      // Skip user messages from self (already added locally)
      if (msg.sender?.id === currentUser?.id && msg.role === "user") {
        seenContents.current.add(msgKey);
        return;
      }
      
      seenContents.current.add(msgKey);
      setMessages((prev) => {
        // Avoid duplicates by checking content
        const isDuplicate = prev.some(
          (m) => m.content === msg.content && m.role === msg.role && 
                 Math.abs(m.timestamp - msg.timestamp) < 5000
        );
        if (isDuplicate) return prev;
        
        return [...prev, {
          ...msg,
          id: `ws-${msg.role}-${Date.now()}-${Math.random()}`,
        }];
      });
    }
  }, [wsMessages, currentUser?.id]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const content = input.trim();
    const contentKey = `user-${content}-${currentUser?.id || 0}`;
    seenContents.current.add(contentKey);

    const userMessage: Message = {
      id: `local-user-${Date.now()}`,
      role: "user",
      content,
      timestamp: Date.now(),
      sender: currentUser,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lobbyId,
          map,
          side,
          tendencies,
          message: content,
          history: messages.slice(-10).map((m) => ({
            role: m.role,
            content: m.content,
          })),
          sender: currentUser,
          players,
          strategyType,
          economy: {
            lossStreak: economy?.lossStreak || 0,
            roundHistory: economy?.roundHistory || [],
          },
          playerPositions: side === "CT" ? playerPositions : undefined,
        }),
      });

      if (!res.ok) throw new Error("Failed to get response");

      const data = await res.json();
      
      // Don't show AI response in chat - it goes to StratCard via onStrategyGenerated
      if (data.strategy) {
        onStrategyGenerated?.(data.strategy);
      } else if (data.response) {
        // Create strategy from response if not provided
        onStrategyGenerated?.({
          primary: {
            title: "IGL Call",
            type: strategyType || "recommended",
            map,
            side,
            content: {
              voice: data.response.split("\n")[0],
              quick: { buy: "", plan: data.response, fallback: "" },
              layering: [],
              roles: {},
              utility: [],
              triggers: [],
              win_conditions: [],
              failure_branches: [],
            },
          },
          selected: strategyType || "recommended",
          source: "chat",
        });
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          role: "assistant",
          content: "Eroare la generare. Încearcă din nou.",
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
      inputRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Calculate loss bonus for display
  const lossBonus = [1400, 1900, 2400, 2900, 3400, 3400][Math.min(economy?.lossStreak || 0, 5)];
  const roundNum = (economy?.roundHistory?.length || 0) + 1;

  return (
    <Card className="border-0 bg-gradient-to-b from-slate-900/80 to-slate-950/90 shadow-2xl">
      <CardHeader className="pb-2 border-b border-emerald-500/20">
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2 text-emerald-400">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Descrie Situația
          </span>
          <div className="flex items-center gap-2">
            <Badge className="bg-slate-700/50 text-slate-300 border-slate-600/50 text-xs">
              R{roundNum}
            </Badge>
            <Badge className="bg-emerald-600/20 text-emerald-300 border-emerald-500/30 text-xs">
              {map} • {side}
            </Badge>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 space-y-3">
        {/* Economy status */}
        <div className="flex items-center justify-between text-xs text-slate-400 px-1">
          <span>Loss Streak: {economy?.lossStreak || 0}</span>
          <span>Loss Bonus: ${lossBonus}</span>
        </div>
        
        {/* Round result buttons */}
        <div className="flex gap-2">
          <button
            onClick={() => economy?.onRoundResult?.(true)}
            className="flex-1 py-2 px-3 rounded-lg bg-green-600/20 border border-green-500/30 text-green-400 text-sm font-medium hover:bg-green-600/30 transition-all"
          >
            WIN +$3250
          </button>
          <button
            onClick={() => economy?.onRoundResult?.(false)}
            className="flex-1 py-2 px-3 rounded-lg bg-red-600/20 border border-red-500/30 text-red-400 text-sm font-medium hover:bg-red-600/30 transition-all"
          >
            LOSS +${lossBonus}
          </button>
          <button
            onClick={() => economy?.onRoundResult?.(false, true)}
            className="py-2 px-3 rounded-lg bg-orange-600/20 border border-orange-500/30 text-orange-400 text-sm font-medium hover:bg-orange-600/30 transition-all"
            title="Lost but planted"
          >
            +Plant
          </button>
        </div>

        {/* Message history - compact */}
        <div className="h-[120px] overflow-y-auto space-y-2 pr-1 scrollbar-thin scrollbar-thumb-emerald-500/20">
          {messages.length === 0 && (
            <div className="text-center text-slate-500 text-sm py-4">
              Scrie situația și AI-ul generează un call în "Ultimul Call"
            </div>
          )}
          {messages.map((msg) => (
            <div key={msg.id} className="flex gap-2 justify-end">
              <div className="bg-slate-800/60 rounded-lg px-3 py-2 text-sm text-slate-300 max-w-[90%]">
                {msg.content}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex items-center gap-2 text-emerald-400 text-sm">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
              <span>Generez call...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="flex gap-2 pt-2 border-t border-slate-800">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ex: runda de pistol, suntem eco, ei full buy..."
            className="flex-1 bg-slate-800/50 border border-slate-700/50 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500/50 placeholder:text-slate-500 transition-all"
            disabled={loading}
          />
          <Button
            onClick={sendMessage}
            disabled={!input.trim() || loading}
            size="sm"
            className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-medium px-4 rounded-xl shadow-lg shadow-emerald-500/20 transition-all"
          >
            {loading ? (
              <span className="animate-spin">⏳</span>
            ) : (
              "Trimite"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
