import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface User {
  id: string;
  username: string;
  faceitAvatar?: string;
}

interface CTPositionsProps {
  map: string;
  side: "CT" | "T";
  members: User[];
  positions: Record<string, string>;
  onPositionsChange: (positions: Record<string, string>) => void;
}

const DEFAULT_POSITIONS: Record<string, Record<string, string>> = {
  Mirage: {
    P1: "Ticket",
    P2: "Connector",
    P3: "Mid Window",
    P4: "Short",
    P5: "B Apartments",
  },
  Dust2: {
    P1: "Long",
    P2: "Car",
    P3: "Mid Doors",
    P4: "B Tunnels",
    P5: "B Platform",
  },
  Inferno: {
    P1: "Pit",
    P2: "Arch",
    P3: "Mid",
    P4: "Banana",
    P5: "B Site",
  },
  Ancient: {
    P1: "A Main",
    P2: "Donut",
    P3: "Mid",
    P4: "B Ramp",
    P5: "B Site",
  },
  Anubis: {
    P1: "A Main",
    P2: "Connector",
    P3: "Mid",
    P4: "B Main",
    P5: "B Site",
  },
  Nuke: {
    P1: "Hut",
    P2: "Heaven",
    P3: "Ramp",
    P4: "Secret",
    P5: "B Site",
  },
  Vertigo: {
    P1: "A Ramp",
    P2: "Elevator",
    P3: "Mid",
    P4: "B Stairs",
    P5: "B Site",
  },
  Overpass: {
    P1: "A Long",
    P2: "Bank",
    P3: "Playground",
    P4: "Water",
    P5: "Monster",
  },
  Train: {
    P1: "A Main",
    P2: "Hell",
    P3: "Pop Dog",
    P4: "B Hall",
    P5: "Upper B",
  },
};

const POSITION_OPTIONS: Record<string, string[]> = {
  Mirage: [
    "Ticket",
    "Connector",
    "Mid Window",
    "Short",
    "B Apartments",
    "Palace",
    "Underpass",
    "Ramp",
    "A Site",
    "Market",
  ],
  Dust2: [
    "Long",
    "Car",
    "Mid Doors",
    "B Tunnels",
    "B Platform",
    "Short",
    "Upper Tunnels",
    "A Ramp",
    "A Site",
    "Pit",
  ],
  Inferno: [
    "Pit",
    "Arch",
    "Mid",
    "Banana",
    "B Site",
    "Apartments",
    "Boiler",
    "T Ramp",
    "Library",
    "Second Mid",
  ],
  Ancient: [
    "A Main",
    "Donut",
    "Mid",
    "B Ramp",
    "B Site",
    "Temple",
    "Cave",
    "Heaven",
    "Default",
    "Dark",
  ],
  Anubis: [
    "A Main",
    "Connector",
    "Mid",
    "B Main",
    "B Site",
    "Temple",
    "Heaven",
    "Water",
    "Bridge",
    "Ruins",
  ],
  Nuke: [
    "Hut",
    "Heaven",
    "Ramp",
    "Secret",
    "B Site",
    "Outside",
    "Garage",
    "Control Room",
    "Vents",
    "Rafters",
  ],
  Vertigo: [
    "A Ramp",
    "Elevator",
    "Mid",
    "B Stairs",
    "B Site",
    "Top",
    "A Site",
    "Yard",
    "Upper B",
    "Lower B",
  ],
  Overpass: [
    "A Long",
    "Bank",
    "Playground",
    "Water",
    "Monster",
    "Fountain",
    "Bathrooms",
    "Truck",
    "Short B",
    "Heaven",
  ],
  Train: [
    "A Main",
    "Hell",
    "Pop Dog",
    "B Hall",
    "Upper B",
    "Ivy",
    "T Con",
    "Lower B",
    "Heaven",
    "Headshot",
  ],
};

export default function CTPositions({
  map,
  side,
  members,
  positions,
  onPositionsChange,
}: CTPositionsProps) {
  const [localPositions, setLocalPositions] = useState<Record<string, string>>(
    {}
  );

  useEffect(() => {
    const defaultMap = DEFAULT_POSITIONS[map] || DEFAULT_POSITIONS["Mirage"];
    if (positions && Object.keys(positions).length > 0) {
      setLocalPositions(positions);
    } else {
      const playerNames =
        members.length >= 5
          ? members.slice(0, 5).map((m) => m.username)
          : ["P1", "P2", "P3", "P4", "P5"];

      const newPositions: Record<string, string> = {};
      playerNames.forEach((name, i) => {
        const posKey = `P${i + 1}`;
        newPositions[name] = defaultMap[posKey] || "A Site";
      });
      setLocalPositions(newPositions);
    }
  }, [map, members, positions]);

  const handlePositionChange = (playerName: string, newPosition: string) => {
    const updated = { ...localPositions, [playerName]: newPosition };
    setLocalPositions(updated);
    onPositionsChange(updated);
  };

  if (side !== "CT") {
    return null;
  }

  const playerNames =
    members.length >= 5
      ? members.slice(0, 5).map((m) => m.username)
      : ["P1", "P2", "P3", "P4", "P5"];

  const positionOptions = POSITION_OPTIONS[map] || POSITION_OPTIONS["Mirage"];

  return (
    <Card className="border-slate-700/50 bg-slate-800/30 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <span className="text-emerald-400">🎯</span>
          Poziții CT
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {playerNames.map((playerName) => (
            <div key={playerName} className="flex items-center gap-3">
              <label className="text-sm font-medium text-slate-300 min-w-[80px]">
                {playerName}
              </label>
              <Select
                value={localPositions[playerName] || ""}
                onValueChange={(value) =>
                  handlePositionChange(playerName, value)
                }
              >
                <SelectTrigger className={cn(
                  "flex-1 h-8 text-sm",
                  "bg-slate-700/50 border border-slate-600/50",
                  "text-white placeholder:text-slate-400",
                  "hover:bg-slate-700/70 hover:border-slate-500/50",
                  "focus:ring-1 focus:ring-emerald-500/50 focus:border-emerald-500/50"
                )}>
                  <SelectValue placeholder="Selectează poziție" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border border-slate-600/50 text-white">
                  {positionOptions.map((position) => (
                    <SelectItem
                      key={position}
                      value={position}
                      className={cn(
                        "focus:bg-emerald-600/30 focus:text-emerald-100",
                        "data-[state=checked]:bg-emerald-600/40 data-[state=checked]:text-emerald-100"
                      )}
                    >
                      {position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ))}
        </div>
        <div className="text-xs text-slate-400 pt-2 border-t border-slate-700/50">
          Schimbări în timp real • {map}
        </div>
      </CardContent>
    </Card>
  );
}
