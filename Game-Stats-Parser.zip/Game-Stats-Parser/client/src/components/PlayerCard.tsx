import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { User } from "@shared/schema";
import { Crown, Shield, Sword, User as UserIcon, Crosshair } from "lucide-react";
import clsx from "clsx";

interface PlayerCardProps {
  member: User & { isReady: boolean; role: string | null };
  isHost: boolean;
}

const roleIcons: Record<string, any> = {
  IGL: Crown,
  Entry: Sword,
  Support: Shield,
  AWP: Crosshair,
  Lurk: UserIcon
};

export function PlayerCard({ member, isHost }: PlayerCardProps) {
  const RoleIcon = member.preferredRole ? roleIcons[member.preferredRole] || UserIcon : UserIcon;

  return (
    <div className={clsx(
      "relative flex items-center gap-4 p-4 rounded-xl border backdrop-blur-sm transition-all",
      member.isReady 
        ? "bg-primary/10 border-primary/50" 
        : "bg-card/50 border-white/5"
    )}>
      <div className="relative">
        <Avatar className="h-12 w-12 border-2 border-white/10">
          <AvatarImage src={member.faceitAvatar || undefined} />
          <AvatarFallback className="bg-muted text-muted-foreground font-mono">
            {member.username.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        {isHost && (
          <div className="absolute -top-2 -right-2 bg-yellow-500 text-black p-0.5 rounded-full">
            <Crown size={12} />
          </div>
        )}
      </div>

      <div className="flex-1">
        <div className="flex items-center gap-2">
          <h4 className="font-display font-bold text-lg">{member.username}</h4>
          {member.faceitElo && (
            <Badge variant="outline" className="text-xs border-orange-500/50 text-orange-400 bg-orange-500/10">
              {member.faceitElo} ELO
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <RoleIcon size={14} />
          <span>{member.preferredRole || "Flex"}</span>
        </div>
      </div>

      <div className={clsx(
        "px-3 py-1 rounded text-xs font-bold uppercase tracking-wider",
        member.isReady ? "bg-primary text-black shadow-[0_0_10px_rgba(0,255,157,0.4)]" : "bg-muted text-muted-foreground"
      )}>
        {member.isReady ? "Ready" : "Waiting"}
      </div>
    </div>
  );
}
