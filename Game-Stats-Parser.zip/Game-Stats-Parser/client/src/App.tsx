// client/src/App.tsx
import { Switch, Route, Router as WouterRouter } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Landing from "@/pages/Landing";
import LobbySelection from "@/pages/LobbySelection";
import Lobby from "@/pages/Lobby";
import MatchDashboard from "@/pages/MatchDashboard";
import Playbook from "@/pages/Playbook";
import NotFound from "@/pages/not-found";

function getWouterBase() {
  const first = window.location.pathname.split("/").filter(Boolean)[0];
  // Replit webview rulează aplicația sub /play uneori
  if (first === "play") return "/play";
  return "";
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/lobbies" component={LobbySelection} />

      {/* Compat: dacă cineva ajunge pe /play (legacy redirect din Landing), îl ducem în LobbySelection */}
      <Route path="/play" component={LobbySelection} />
      <Route path="/play/:rest*" component={LobbySelection} />

      <Route path="/lobby/:id" component={Lobby} />
      <Route path="/lobby/:id/:rest*" component={Lobby} />

      <Route path="/match/:id" component={MatchDashboard} />
      <Route path="/match/:id/:rest*" component={MatchDashboard} />

      <Route path="/playbook" component={Playbook} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={getWouterBase()}>
          <div className="dark bg-background min-h-screen text-foreground font-body">
            <Router />
            <Toaster />
          </div>
        </WouterRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
