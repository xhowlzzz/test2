import { useEffect, useMemo, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

type WSMessage = { type: string; data?: any; payload?: any };

export function useWebSocket(lobbyId?: number) {
  const socketRef = useRef<WebSocket | null>(null);
  const queryClient = useQueryClient();

  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WSMessage | null>(null);

  useEffect(() => {
    if (!lobbyId) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      ws.send(JSON.stringify({ type: "join_lobby", lobbyId }));
    };

    ws.onclose = () => setIsConnected(false);
    ws.onerror = () => setIsConnected(false);

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.type === "lobby_update") {
          // normalize pentru MatchDashboard (care verifică LOBBY_UPDATE)
          setLastMessage({ type: "LOBBY_UPDATE", data: data.data });

          queryClient.invalidateQueries({
            queryKey: [api.lobbies.get.path, lobbyId],
          });
          return;
        }

        setLastMessage(data);
      } catch (e) {
        console.error("WS parse error", e);
      }
    };

    return () => {
      try {
        ws.close();
      } catch {}
      socketRef.current = null;
      setIsConnected(false);
    };
  }, [lobbyId, queryClient]);

  const sendMessage = useMemo(() => {
    return (msg: any) => {
      const ws = socketRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN) return;
      ws.send(JSON.stringify(msg));
    };
  }, []);

  return { sendMessage, lastMessage, isConnected };
}
