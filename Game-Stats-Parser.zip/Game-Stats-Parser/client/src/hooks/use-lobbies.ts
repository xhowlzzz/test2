import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { InsertLobby } from "@shared/schema";

export function useLobby(id: number) {
  return useQuery({
    queryKey: [api.lobbies.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.lobbies.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Lobby not found");
      return api.lobbies.get.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Fallback polling if WS fails
  });
}

export function useCreateLobby() {
  return useMutation({
    mutationFn: async (data: { hostId: number; map: string }) => {
      const res = await fetch(api.lobbies.create.path, {
        method: api.lobbies.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create lobby");
      return api.lobbies.create.responses[201].parse(await res.json());
    },
  });
}

export function useJoinLobby() {
  return useMutation({
    mutationFn: async (data: { code: string; userId: number }) => {
      const res = await fetch(api.lobbies.join.path, {
        method: api.lobbies.join.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to join lobby");
      return api.lobbies.join.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateLobbyState() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & any) => {
      const url = buildUrl(api.lobbies.updateState.path, { id });
      const res = await fetch(url, {
        method: api.lobbies.updateState.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (!res.ok) throw new Error("Failed to update lobby state");
      return api.lobbies.updateState.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.lobbies.get.path, variables.id] });
    },
  });
}

export function useCloseLobby() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.lobbies.updateState.path, { id });
      const res = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: false }),
      });
      if (!res.ok) throw new Error("Failed to close lobby");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.lobbies.get.path] });
    },
  });
}
