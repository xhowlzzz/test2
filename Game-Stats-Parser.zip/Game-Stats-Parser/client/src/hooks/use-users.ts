import { useQuery, useMutation } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { InsertUser } from "@shared/schema";
import { z } from "zod";

export function useCreateUser() {
  return useMutation({
    mutationFn: async (data: InsertUser) => {
      const res = await fetch(api.users.create.path, {
        method: api.users.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create user");
      return api.users.create.responses[201].parse(await res.json());
    },
  });
}

export function useFaceitStats(nickname: string) {
  return useQuery({
    queryKey: [api.users.getFaceit.path, nickname],
    queryFn: async () => {
      if (!nickname) return null;
      const url = buildUrl(api.users.getFaceit.path, { nickname });
      const res = await fetch(url);
      if (!res.ok) return null;
      return api.users.getFaceit.responses[200].parse(await res.json());
    },
    enabled: !!nickname && nickname.length > 2,
    retry: false,
  });
}
