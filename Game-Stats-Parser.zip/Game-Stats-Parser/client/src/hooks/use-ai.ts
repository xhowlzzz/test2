import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

type GenerateStratInput = z.infer<typeof api.ai.generate.input>;

export function useGenerateStrat() {
  return useMutation({
    mutationFn: async (data: GenerateStratInput) => {
      const res = await fetch(api.ai.generate.path, {
        method: api.ai.generate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to generate strategy");
      return api.ai.generate.responses[200].parse(await res.json());
    },
  });
}
