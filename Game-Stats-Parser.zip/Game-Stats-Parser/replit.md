# CS2 AI IGL - StratOS

## Overview
AI-powered In-Game Leader assistant for Counter-Strike 2 that generates tactical strategies based on game context.

## Features
- **Chat-based IGL**: Describe your situation in chat and get 3 strategies displayed side-by-side (Recomandat, Sigur, Risc)
- **Groq AI Strategies**: Uses Llama 3.3 70B via Groq (free, 14,400 req/day) for complex strategy generation with player-specific roles
- **CT Positions**: Configure player positions per map for CT side
- **Real-time Lobby Sync**: WebSocket-based synchronization for all lobby members
- **Economy Tracking**: Loss streak and round history persisted in localStorage
- **Romanian Interface**: UI in Romanian, callouts/weapons/utility in English

## Tech Stack
- **Frontend**: React + Vite + TypeScript + TailwindCSS + shadcn/ui
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **AI**: Groq API (llama-3.3-70b-versatile) - free tier, 14,400 requests/day
- **OCR**: Tesseract.js (browser-side)
- **Real-time**: WebSockets

## Project Structure
```
client/                 # React frontend
  src/
    components/        # UI components
      ScreenAssist.tsx # OCR screen capture component
      StratCard.tsx    # Strategy display card
    hooks/             # React hooks
      use-ai.ts        # AI generation hook
      use-lobbies.ts   # Lobby management hooks
      use-websocket.ts # WebSocket hook
    pages/             # Page components
      MatchDashboard.tsx # Main match interface

server/                # Express backend
  engine/
    groq-igl.ts       # Groq AI strategy generation (primary)
    groq-chat.ts      # Groq AI chat engine
    gemini-igl.ts     # Gemini AI fallback
    igl.ts            # Local fallback strategy engine
  routes.ts           # API endpoints
  storage.ts          # Database operations

shared/               # Shared types and schemas
  schema.ts           # Drizzle ORM schemas
  routes.ts           # API route definitions
```

## Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (auto-configured)
- `GROQ_API_KEY`: Groq API key for AI strategies (free, no credit card required)
- `FACEIT_API_KEY`: FACEIT API key for player ELO lookup

## Recent Changes
- **2026-01-31**: Replaced Gemini with Groq (free 14,400 req/day, no rate limits)
- **2026-01-31**: Chat messages now sync across all lobby members via WebSocket
- **2026-01-31**: Chat shows sender name and FACEIT avatar for each message
- **2026-01-31**: Improved chat UI with gradient design, AI avatar, and better styling
- **2026-01-31**: Using gemini-2.5-flash for chat responses
- **2026-01-31**: Removed OCR/Screen Assist for simpler UX - users now chat with AI directly
- **2026-01-31**: Removed Quick Events, My Role, and Economy sections for cleaner UI
- **2026-01-31**: Strategy type selection (Recommended/Safe/High Risk) - generates only selected type
- **2026-01-31**: Real-time strategy sync via WebSockets

## User Preferences
- Romanian language for in-game calls and UI text
- Chip-style buttons for opponent tendencies with emoji icons
- Orange accent color for active/selected states
- Clean, minimal UI focused on essential features
